import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  RiCloseLine, 
  RiBuilding2Line, 
  RiMailLine, 
  RiGlobalLine, 
  RiShieldUserLine, 
  RiBankCardLine,
  RiCheckLine,
  RiInformationLine
} from 'react-icons/ri';
import Input from '../Input';
import Button from '../Button';

const CreateOrganisationModal = ({ isOpen, onClose, onSubmit }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    slug: '',
    primaryEmail: '',
    country: '',
    plan: 'starter',
    adminFirstName: '',
    adminLastName: '',
    adminEmail: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Auto-generate slug from name
    if (name === 'name') {
      const generatedSlug = value.toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
      setFormData(prev => ({ ...prev, slug: generatedSlug }));
    }
  };

  const handleNext = () => setStep(prev => prev + 1);
  const handlePrev = () => setStep(prev => prev - 1);

  const modalVariants = {
    hidden: { opacity: 0, scale: 0.9, y: 20 },
    visible: { opacity: 1, scale: 1, y: 0 },
    exit: { opacity: 0, scale: 0.9, y: 20 }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Overlay */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-secondary/40 backdrop-blur-sm"
        />

        {/* Modal Card */}
        <motion.div
          variants={modalVariants}
          initial="hidden"
          animate="visible"
          exit="exit"
          className="relative bg-white w-full max-w-2xl rounded-[40px] shadow-2xl overflow-hidden border border-gray-100"
        >
          {/* Header */}
          <div className="p-8 border-b border-gray-50 flex items-center justify-between bg-gray-50/50">
            <div>
              <h2 className="text-2xl font-black text-secondary tracking-tight">Onboard Organisation</h2>
              <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mt-1">Step {step} of 3: {
                step === 1 ? 'Company Details' : step === 2 ? 'Subscription Plan' : 'Primary Admin'
              }</p>
            </div>
            <button onClick={onClose} className="p-2 text-gray-400 hover:text-secondary bg-white rounded-2xl shadow-sm border border-gray-100 transition-all">
              <RiCloseLine size={24} />
            </button>
          </div>

          {/* Form Content */}
          <div className="p-8">
            <div className="space-y-6">
              {step === 1 && (
                <motion.div initial={{ x: 20, opacity: 0 }} animate={{ x: 0, opacity: 1 }} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input
                      label="Organisation Name"
                      name="name"
                      placeholder="e.g. Elite Visa Solutions"
                      value={formData.name}
                      onChange={handleChange}
                      icon={RiBuilding2Line}
                      required
                    />
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Subdomain / Slug</label>
                      <div className="relative">
                        <input
                          name="slug"
                          value={formData.slug}
                          onChange={handleChange}
                          className="w-full pl-4 pr-24 py-3 bg-gray-50 border border-gray-100 rounded-2xl text-sm font-bold text-secondary focus:ring-2 focus:ring-primary/20 outline-none"
                          placeholder="elite-visa"
                        />
                        <span className="absolute right-4 top-1/2 -translate-y-1/2 text-[10px] font-black text-gray-400">.epic-crm.com</span>
                      </div>
                    </div>
                  </div>
                  <Input
                    label="Primary Business Email"
                    name="primaryEmail"
                    type="email"
                    placeholder="contact@organisation.com"
                    value={formData.primaryEmail}
                    onChange={handleChange}
                    icon={RiMailLine}
                    required
                  />
                  <Input
                    label="Country"
                    name="country"
                    placeholder="United Kingdom"
                    value={formData.country}
                    onChange={handleChange}
                    icon={RiGlobalLine}
                    required
                  />
                </motion.div>
              )}

              {step === 2 && (
                <motion.div initial={{ x: 20, opacity: 0 }} animate={{ x: 0, opacity: 1 }} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {[
                      { id: 'starter', name: 'Starter', price: 99, modules: ['Dashboard', 'Cases'] },
                      { id: 'pro', name: 'Professional', price: 299, modules: ['Dashboard', 'Cases', 'Docs', 'Team'] },
                      { id: 'enterprise', name: 'Enterprise', price: 599, modules: ['All Modules'] },
                    ].map((plan) => (
                      <div 
                        key={plan.id}
                        onClick={() => setFormData(prev => ({ ...prev, plan: plan.id }))}
                        className={`relative p-6 rounded-3xl border-2 cursor-pointer transition-all ${
                          formData.plan === plan.id 
                            ? 'border-primary bg-primary/5' 
                            : 'border-gray-100 hover:border-gray-200'
                        }`}
                      >
                        {formData.plan === plan.id && (
                          <div className="absolute -top-2 -right-2 w-6 h-6 bg-primary text-white rounded-full flex items-center justify-center shadow-lg">
                            <RiCheckLine size={14} />
                          </div>
                        )}
                        <h4 className="font-black text-secondary uppercase tracking-tight mb-1">{plan.name}</h4>
                        <p className="text-lg font-black text-primary">£{plan.price}<span className="text-[10px] text-gray-400">/mo</span></p>
                        
                        <div className="mt-4 pt-4 border-t border-gray-100">
                          <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-2">Modules:</p>
                          <div className="flex flex-wrap gap-1">
                            {plan.modules.map(m => (
                              <span key={m} className="px-2 py-0.5 bg-white border border-gray-100 rounded text-[9px] font-bold text-secondary">{m}</span>
                            ))}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="md:col-span-3 p-4 bg-blue-50 rounded-2xl flex gap-3 border border-blue-100">
                    <RiInformationLine className="text-blue-500 shrink-0" size={20} />
                    <p className="text-[10px] font-bold text-blue-700 leading-relaxed uppercase">
                      Subscription will begin in "Trial" mode for 14 days. Billing will be automatically generated after the trial period.
                    </p>
                  </div>
                </motion.div>
              )}

              {step === 3 && (
                <motion.div initial={{ x: 20, opacity: 0 }} animate={{ x: 0, opacity: 1 }} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input
                      label="Admin First Name"
                      name="adminFirstName"
                      placeholder="John"
                      value={formData.adminFirstName}
                      onChange={handleChange}
                      icon={RiShieldUserLine}
                      required
                    />
                    <Input
                      label="Admin Last Name"
                      name="adminLastName"
                      placeholder="Doe"
                      value={formData.adminLastName}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <Input
                    label="Admin Login Email"
                    name="adminEmail"
                    type="email"
                    placeholder="admin@organisation.com"
                    value={formData.adminEmail}
                    onChange={handleChange}
                    icon={RiMailLine}
                    required
                  />
                  <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100">
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 text-center">Auto-Generated Password</p>
                    <p className="text-center font-black text-secondary tracking-[0.3em]">EPIC-TEMP-2024</p>
                  </div>
                </motion.div>
              )}
            </div>
          </div>

          {/* Footer */}
          <div className="p-8 border-t border-gray-50 bg-gray-50/30 flex items-center justify-between">
            {step > 1 ? (
              <button onClick={handlePrev} className="px-8 py-3 rounded-2xl font-black text-xs text-gray-500 hover:text-secondary uppercase tracking-widest transition-all">
                Back
              </button>
            ) : <div />}
            
            <Button 
              onClick={step < 3 ? handleNext : () => onSubmit(formData)}
              className="px-10"
            >
              {step < 3 ? 'Continue' : 'Finalize & Create'}
            </Button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export default CreateOrganisationModal;
