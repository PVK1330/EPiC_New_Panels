import { NavLink, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  RiDashboardLine,
  RiOrganizationChart,
  RiAddBoxLine,
  RiShieldUserLine,
  RiSettings4Line,
  RiHistoryLine,
  RiPulseLine,
  RiBillLine,
  RiGroupLine,
  RiLockPasswordLine,
  RiFileSettingsLine,
  RiTimeLine,
  RiCloseLine,
  RiBarChartLine,
} from "react-icons/ri";

const sidebarVariants = {
  open: { x: 0, opacity: 1, transition: { type: "spring", stiffness: 300, damping: 30 } },
  closed: { x: "-100%", opacity: 0, transition: { type: "spring", stiffness: 300, damping: 30 } },
};

const navSections = [
  {
    title: "Overview",
    items: [
      { name: "Dashboard", path: "/superadmin/dashboard", icon: RiDashboardLine },
      { name: "Global Audit Log", path: "/superadmin/audit-log", icon: RiHistoryLine },
    ],
  },
  {
    title: "Organisations",
    items: [
      { name: "All Organisations", path: "/superadmin/organisations", icon: RiOrganizationChart },
    ],
  },
  {
    title: "Subscriptions",
    items: [
      { name: "Plans Management", path: "/superadmin/plans", icon: RiFileSettingsLine },
      { name: "Billing & Revenue", path: "/superadmin/billing", icon: RiBillLine },
    ],
  },
];

const SuperadminSidebar = ({ isOpen, onClose }) => {
  const location = useLocation();

  const SidebarContent = () => (
    <div className="flex flex-col h-full bg-white border-r border-gray-100 shadow-xl lg:shadow-none">
      {/* Brand Header */}
      <div className="h-16 flex items-center px-6 border-b border-gray-50 shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 bg-primary rounded-xl flex items-center justify-center text-white shadow-lg shadow-primary/20">
            <RiShieldUserLine size={22} />
          </div>
          <div>
            <h1 className="text-sm font-black text-secondary leading-none uppercase tracking-tighter">
              EPiC CRM
            </h1>
            <p className="text-[10px] font-bold text-primary mt-0.5 tracking-widest uppercase">
              SuperAdmin
            </p>
          </div>
        </div>
        {/* Mobile close button */}
        <button
          onClick={onClose}
          className="lg:hidden ml-auto p-2 text-gray-400 hover:text-gray-600 transition-colors"
        >
          <RiCloseLine size={24} />
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-6 px-4 custom-scrollbar">
        {navSections.map((section, idx) => (
          <div key={section.title} className={idx !== 0 ? "mt-8" : ""}>
            <p className="px-3 mb-2 text-[11px] font-black text-gray-400 uppercase tracking-widest">
              {section.title}
            </p>
            <div className="space-y-0.5">
              {section.items.map((item) => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  onClick={() => window.innerWidth < 1024 && onClose()}
                  className={({ isActive }) =>
                    `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-bold transition-all group ${
                      isActive
                        ? "bg-primary/5 text-primary shadow-sm shadow-primary/5"
                        : "text-gray-500 hover:bg-gray-50 hover:text-secondary"
                    }`
                  }
                >
                  <item.icon
                    size={20}
                    className="group-hover:scale-110 transition-transform"
                  />
                  <span>{item.name}</span>
                </NavLink>
              ))}
            </div>
          </div>
        ))}
      </nav>

      {/* Footer / System Status */}
      <div className="p-4 border-t border-gray-50 bg-gray-50/30">
        <div className="flex items-center gap-3 p-3 rounded-xl bg-white border border-gray-100 shadow-sm">
          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
          <div className="flex-1 min-w-0">
            <p className="text-[10px] font-black text-secondary truncate uppercase">Platform Status</p>
            <p className="text-[10px] text-green-600 font-bold uppercase">All systems operational</p>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Mobile Overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-secondary/30 backdrop-blur-sm z-40 lg:hidden"
          />
        )}
      </AnimatePresence>

      {/* Sidebar Desktop */}
      <aside className="hidden lg:block w-64 h-full shrink-0">
        <SidebarContent />
      </aside>

      {/* Sidebar Mobile */}
      <motion.aside
        variants={sidebarVariants}
        initial="closed"
        animate={isOpen ? "open" : "closed"}
        className="fixed inset-y-0 left-0 w-72 z-50 lg:hidden shadow-2xl"
      >
        <SidebarContent />
      </motion.aside>
    </>
  );
};

export default SuperadminSidebar;
