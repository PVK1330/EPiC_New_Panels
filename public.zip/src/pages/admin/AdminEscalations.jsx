import { useState, useEffect, useCallback } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { FiEye, FiDownload, FiPlus, FiEdit2, FiTrash2, FiUserCheck } from "react-icons/fi";
import { RiAlarmWarningLine } from "react-icons/ri";
import { Loader2, X } from "lucide-react";
import { useToast } from "../../context/ToastContext";
import { getEscalations, createEscalation, updateEscalation, assignEscalation, deleteEscalation, exportEscalationsExcel } from "../../services/escalationApi";
import { getCases } from "../../services/caseApi";
import { getAdmins } from "../../services/adminApi";

const OTHER_CATEGORY_MARKER = /\n\n\(Other category:\s([\s\S]+?)\)\s*$/;

const parseTriggerStoredWithOtherCategory = (triggerText, triggerType) => {
  if (triggerType !== "Other" || typeof triggerText !== "string") {
    return { triggerBody: triggerText || "", otherCategory: "" };
  }
  const m = triggerText.match(OTHER_CATEGORY_MARKER);
  if (m) {
    return { triggerBody: triggerText.slice(0, m.index), otherCategory: m[1].trim() };
  }
  return { triggerBody: triggerText || "", otherCategory: "" };
};

const buildTriggerForApi = (trigger, triggerType, otherCategory) => {
  const trimmed = (trigger || "").trim();
  const other = (otherCategory || "").trim();
  if (triggerType === "Other" && other) {
    return trimmed ? `${trimmed}\n\n(Other category: ${other})` : `(Other category: ${other})`;
  }
  return trimmed;
};

const omitTriggerTypeOther = ({ triggerTypeOther, ...rest }) => rest;

const SEVERITY_FILTER = ["All", "Critical", "High", "Medium", "Low"];
const TYPE_FILTER = ["All", "Deadline Breach", "Missing Docs", "Stuck Case"];

const AdminEscalations = () => {
  const { showToast } = useToast();
  const [sev, setSev] = useState("All");
  const [typ, setTyp] = useState("All");
  const [loading, setLoading] = useState(false);
  const [escalations, setEscalations] = useState([]);
  const [cases, setCases] = useState([]);
  const [admins, setAdmins] = useState([]);
  const [kpi, setKpi] = useState({
    critical: 0,
    high: 0,
    medium: 0,
    resolvedToday: 0,
  });
  const [showModal, setShowModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [editingEscalation, setEditingEscalation] = useState(null);
  const [assigningEscalation, setAssigningEscalation] = useState(null);
  const [creating, setCreating] = useState(false);
  const [updating, setUpdating] = useState(false);
  const [assigning, setAssigning] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [formData, setFormData] = useState({
    caseId: "",
    candidate: "",
    severity: "Medium",
    trigger: "",
    triggerType: "Deadline Breach",
    triggerTypeOther: "",
    assignedAdminId: null,
    relatedCaseId: null,
    notes: "",
  });
  const [assignData, setAssignData] = useState({
    assignedAdminId: null,
  });

  useEffect(() => {
    fetchCases();
    fetchAdmins();
  }, []);

  const fetchAdmins = async () => {
    try {
      const res = await getAdmins();
      if (res.data?.data?.admins) {
        setAdmins(res.data.data.admins);
      }
    } catch (e) {
      console.error("Failed to fetch admins:", e);
    }
  };

  const fetchCases = async () => {
    try {
      const res = await getCases(1, 1000);
      if (res.data?.data?.cases) {
        setCases(res.data.data.cases);
      }
    } catch (e) {
      console.error("Failed to fetch cases:", e);
    }
  };

  const listQueryParams = useCallback(() => {
    const params = {};
    if (sev !== "All") params.severity = sev;
    if (typ !== "All") params.quickTypeFilter = typ;
    return params;
  }, [sev, typ]);

  const fetchEscalations = useCallback(async () => {
    setLoading(true);
    try {
      const res = await getEscalations(listQueryParams());
      if (res.data?.status === "success") {
        const data = res.data.data;
        setEscalations(data.escalations || []);
        setKpi(data.kpi || { critical: 0, high: 0, medium: 0, resolvedToday: 0 });
      }
    } catch (e) {
      console.error("Failed to fetch escalations:", e);
    } finally {
      setLoading(false);
    }
  }, [listQueryParams]);

  useEffect(() => {
    fetchEscalations();
  }, [fetchEscalations]);

  const handleExport = async () => {
    setExporting(true);
    try {
      const res = await exportEscalationsExcel(listQueryParams());
      const blob = new Blob([res.data], {
        type:
          res.headers["content-type"] ||
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `escalations_${new Date().toISOString().split("T")[0]}.xlsx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      showToast({ message: "Escalations exported successfully", variant: "success" });
    } catch (e) {
      console.error("Failed to export escalations:", e);
      showToast({ message: "Failed to export escalations", variant: "danger" });
    } finally {
      setExporting(false);
    }
  };

  const handleCreateEscalation = async (e) => {
    e.preventDefault();
    if (formData.triggerType === "Other" && !formData.triggerTypeOther?.trim()) {
      showToast({
        message: 'Please specify what "Other" means (e.g. a short category or label).',
        variant: "danger",
      });
      return;
    }
    setCreating(true);
    try {
      const payload = {
        ...omitTriggerTypeOther(formData),
        trigger: buildTriggerForApi(formData.trigger, formData.triggerType, formData.triggerTypeOther),
      };
      const res = await createEscalation(payload);
      if (res.data?.status === "success") {
        showToast({
          message: "Escalation created successfully",
          variant: "success",
        });
        setShowModal(false);
        setFormData({
          caseId: "",
          candidate: "",
          severity: "Medium",
          trigger: "",
          triggerType: "Deadline Breach",
          triggerTypeOther: "",
          assignedAdminId: null,
          relatedCaseId: null,
          notes: "",
        });
        fetchEscalations();
      }
    } catch (e) {
      console.error("Failed to create escalation:", e);
      showToast({
        message: "Failed to create escalation",
        variant: "danger",
      });
    } finally {
      setCreating(false);
    }
  };

  const handleUpdateEscalation = async (e) => {
    e.preventDefault();
    if (formData.triggerType === "Other" && !formData.triggerTypeOther?.trim()) {
      showToast({
        message: 'Please specify what "Other" means (e.g. a short category or label).',
        variant: "danger",
      });
      return;
    }
    setUpdating(true);
    try {
      const payload = {
        ...omitTriggerTypeOther(formData),
        trigger: buildTriggerForApi(formData.trigger, formData.triggerType, formData.triggerTypeOther),
      };
      const res = await updateEscalation(editingEscalation.id, payload);
      if (res.data?.status === "success") {
        showToast({
          message: "Escalation updated successfully",
          variant: "success",
        });
        setShowEditModal(false);
        setEditingEscalation(null);
        setFormData({
          caseId: "",
          candidate: "",
          severity: "Medium",
          trigger: "",
          triggerType: "Deadline Breach",
          triggerTypeOther: "",
          assignedAdminId: null,
          relatedCaseId: null,
          notes: "",
        });
        fetchEscalations();
      }
    } catch (e) {
      console.error("Failed to update escalation:", e);
      showToast({
        message: "Failed to update escalation",
        variant: "danger",
      });
    } finally {
      setUpdating(false);
    }
  };

  const handleAssignEscalation = async (e) => {
    e.preventDefault();
    setAssigning(true);
    try {
      const res = await assignEscalation(assigningEscalation.id, assignData);
      if (res.data?.status === "success") {
        showToast({
          message: "Escalation assigned successfully",
          variant: "success",
        });
        setShowAssignModal(false);
        setAssigningEscalation(null);
        setAssignData({ assignedAdminId: null });
        fetchEscalations();
      }
    } catch (e) {
      console.error("Failed to assign escalation:", e);
      showToast({
        message: "Failed to assign escalation",
        variant: "danger",
      });
    } finally {
      setAssigning(false);
    }
  };

  const handleDeleteEscalation = async (id) => {
    if (!confirm("Are you sure you want to delete this escalation?")) return;
    try {
      const res = await deleteEscalation(id);
      if (res.data?.status === "success") {
        showToast({
          message: "Escalation deleted successfully",
          variant: "success",
        });
        fetchEscalations();
      }
    } catch (e) {
      console.error("Failed to delete escalation:", e);
      showToast({
        message: "Failed to delete escalation",
        variant: "danger",
      });
    }
  };

  const openEditModal = (esc) => {
    setEditingEscalation(esc);
    const tt = esc.triggerType || "Other";
    const { triggerBody, otherCategory } = parseTriggerStoredWithOtherCategory(esc.trigger, tt);
    setFormData({
      caseId: esc.caseId || "",
      candidate: esc.candidate || "",
      severity: esc.severity || "Medium",
      trigger: triggerBody,
      triggerType: tt,
      triggerTypeOther: otherCategory,
      assignedAdminId: esc.assignedAdminId || null,
      relatedCaseId: esc.relatedCaseId || null,
      notes: esc.notes || "",
    });
    setShowEditModal(true);
  };

  const handleCaseChange = (caseId) => {
    const selectedCase = cases.find(c => c.caseId === caseId);
    setFormData({
      ...formData,
      caseId,
      candidate: selectedCase?.candidate ? `${selectedCase.candidate.first_name} ${selectedCase.candidate.last_name}` : "",
      relatedCaseId: selectedCase?.id || null,
    });
  };

  const openAssignModal = (esc) => {
    setAssigningEscalation(esc);
    setAssignData({ assignedAdminId: esc.assignedAdminId || null });
    setShowAssignModal(true);
  };

  // Map API data to UI format
  const mappedKPI = [
    { label: "Critical", value: kpi.critical, sub: "Immediate action", bg: "bg-red-50", border: "border-red-100", valueClass: "text-red-600" },
    { label: "High Severity", value: kpi.high, sub: "This week", bg: "bg-amber-50", border: "border-amber-100", valueClass: "text-amber-600" },
    { label: "Medium", value: kpi.medium, sub: "Monitor closely", bg: "bg-blue-50", border: "border-blue-100", valueClass: "text-blue-600" },
    { label: "Resolved Today", value: kpi.resolvedToday, sub: "Good progress", bg: "bg-green-50", border: "border-green-100", valueClass: "text-green-600" },
  ];

  const mappedRows = escalations.map((esc) => {
    const severityClass = esc.severity === "Critical" ? "bg-red-100 text-red-700" : esc.severity === "High" ? "bg-amber-100 text-amber-800" : esc.severity === "Medium" ? "bg-blue-100 text-blue-800" : "bg-gray-100 text-gray-600";
    const statusClass = esc.status === "Resolved" ? "bg-green-100 text-green-800" : esc.status === "In Progress" ? "bg-amber-100 text-amber-800" : "bg-red-100 text-red-700";
    const daysClass = esc.daysOpen > 10 ? "text-red-500 font-bold" : esc.daysOpen > 5 ? "text-amber-600 font-bold" : "text-gray-500";
    
    return {
      id: esc.id,
      caseId: esc.caseId || `VF-${esc.relatedCaseId}`,
      candidate: esc.candidate || "Unknown",
      severity: esc.severity,
      severityClass: severityClass,
      trigger: esc.trigger,
      admin: esc.assignedAdmin ? `${esc.assignedAdmin.first_name} ${esc.assignedAdmin.last_name}` : "Unassigned",
      daysOpen: `${esc.daysOpen} days`,
      daysClass: daysClass,
      status: esc.status,
      statusClass: statusClass,
    };
  });

  return (
    <motion.div
      className="space-y-6 pb-10"
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
        <div className="flex items-start gap-3">
          <RiAlarmWarningLine size={32} className="text-primary shrink-0 mt-1" />
          <div>
            <h1 className="text-3xl font-black text-secondary tracking-tight">Escalations &amp; Red Flags</h1>
            <p className="text-sm text-gray-500 mt-0.5">{escalations.length} active cases requiring urgent attention</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => setShowModal(true)}
            className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-bold text-white bg-secondary border border-secondary rounded-xl hover:bg-secondary/90 transition-colors shadow-sm shrink-0 self-start"
          >
            <FiPlus size={14} />
            Create Escalation
          </button>
          <button
            type="button"
            onClick={handleExport}
            disabled={exporting}
            className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-bold text-gray-600 bg-white border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors shadow-sm shrink-0 self-start disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {exporting ? <Loader2 size={14} className="animate-spin" /> : <FiDownload size={14} />}
            Export
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {mappedKPI.map((k) => (
          <div key={k.label} className={`rounded-xl border p-4 ${k.bg} ${k.border}`}>
            <p className="text-[11px] font-bold text-gray-400 uppercase tracking-wide mb-1">{k.label}</p>
            <p className={`text-3xl font-black ${k.valueClass}`}>{k.value}</p>
            <p className="text-xs text-gray-500 mt-1">{k.sub}</p>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-100 flex flex-col sm:flex-row gap-3 flex-wrap">
          <select
            value={sev}
            onChange={(e) => setSev(e.target.value)}
            className="text-sm border border-gray-200 rounded-xl px-3 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-secondary/30 text-gray-600"
          >
            {SEVERITY_FILTER.map((o) => (
              <option key={o} value={o === "All" ? "All" : o}>
                {o === "All" ? "All Severities" : o}
              </option>
            ))}
          </select>
          <select
            value={typ}
            onChange={(e) => setTyp(e.target.value)}
            className="text-sm border border-gray-200 rounded-xl px-3 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-secondary/30 text-gray-600"
          >
            {TYPE_FILTER.map((o) => (
              <option key={o} value={o === "All" ? "All" : o}>
                {o === "All" ? "All Types" : o}
              </option>
            ))}
          </select>
        </div>

        <div className="overflow-x-auto relative min-h-[200px]">
          {loading && (
            <div className="absolute inset-0 z-10 flex items-center justify-center bg-white/60">
              <Loader2 className="w-10 h-10 animate-spin text-secondary" />
            </div>
          )}
          <table className="w-full min-w-[900px]">
            <thead>
              <tr className="bg-gray-50 text-left">
                {["Case ID", "Candidate", "Severity", "Trigger Reason", "Assigned Admin", "Days Open", "Status", "Actions"].map((h, i) => (
                  <th key={i} className="px-4 py-3 text-[10px] font-black text-gray-400 uppercase tracking-wider whitespace-nowrap">
                    {h || " "}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {!loading && mappedRows.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-5 py-12 text-center text-sm text-gray-400">
                    No escalations match your filters.
                  </td>
                </tr>
              ) : (
                mappedRows.map((r) => (
                  <tr key={r.id} className="hover:bg-gray-50/80 transition-colors">
                    <td className="px-4 py-3 font-mono text-sm font-bold text-primary whitespace-nowrap">#{r.caseId}</td>
                    <td className="px-4 py-3 text-sm font-semibold text-secondary whitespace-nowrap">{r.candidate}</td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-black ${r.severityClass}`}>{r.severity}</span>
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-600 max-w-xs">{r.trigger}</td>
                    <td className="px-4 py-3 text-sm text-gray-700 whitespace-nowrap">{r.admin}</td>
                    <td className={`px-4 py-3 text-xs font-mono whitespace-nowrap ${r.daysClass}`}>{r.daysOpen}</td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-black ${r.statusClass}`}>{r.status}</span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        <Link
                          to={`/admin/case-detail/${r.caseId}`}
                          className="inline-flex p-2 rounded-lg text-gray-400 hover:text-secondary hover:bg-blue-50 transition-colors"
                          title="View"
                        >
                          <FiEye size={15} />
                        </Link>
                        <button
                          onClick={() => openEditModal(escalations.find(e => e.id === r.id))}
                          className="inline-flex p-2 rounded-lg text-gray-400 hover:text-secondary hover:bg-blue-50 transition-colors"
                          title="Edit"
                        >
                          <FiEdit2 size={15} />
                        </button>
                        <button
                          onClick={() => openAssignModal(escalations.find(e => e.id === r.id))}
                          className="inline-flex p-2 rounded-lg text-gray-400 hover:text-secondary hover:bg-blue-50 transition-colors"
                          title="Assign"
                        >
                          <FiUserCheck size={15} />
                        </button>
                        <button
                          onClick={() => handleDeleteEscalation(r.id)}
                          className="inline-flex p-2 rounded-lg text-gray-400 hover:text-red-500 hover:bg-red-50 transition-colors"
                          title="Delete"
                        >
                          <FiTrash2 size={15} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
              <h2 className="text-lg font-black text-secondary">Create New Escalation</h2>
              <button
                onClick={() => setShowModal(false)}
                className="p-2 rounded-lg text-gray-400 hover:text-gray-600 hover:bg-gray-100 transition-colors"
              >
                <X size={20} />
              </button>
            </div>
            <form onSubmit={handleCreateEscalation} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Case ID</label>
                <select
                  value={formData.caseId}
                  onChange={(e) => handleCaseChange(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-secondary/30 text-sm bg-white"
                  required
                >
                  <option value="">Select a case</option>
                  {cases.map((c) => (
                    <option key={c.caseId} value={c.caseId}>
                      {c.caseId} — {c.candidate ? `${c.candidate.first_name} ${c.candidate.last_name}` : 'Unknown'}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Candidate Name</label>
                <input
                  type="text"
                  value={formData.candidate}
                  onChange={(e) => setFormData({ ...formData, candidate: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-secondary/30 text-sm bg-gray-50"
                  placeholder="Auto-populated from case selection"
                  readOnly
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Severity</label>
                <select
                  value={formData.severity}
                  onChange={(e) => setFormData({ ...formData, severity: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-secondary/30 text-sm bg-white"
                >
                  <option value="Critical">Critical</option>
                  <option value="High">High</option>
                  <option value="Medium">Medium</option>
                  <option value="Low">Low</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Trigger Reason</label>
                <textarea
                  value={formData.trigger}
                  onChange={(e) => setFormData({ ...formData, trigger: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-secondary/30 text-sm resize-none"
                  rows={3}
                  placeholder="Describe the escalation reason..."
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Trigger Type</label>
                <select
                  value={formData.triggerType}
                  onChange={(e) => {
                    const next = e.target.value;
                    setFormData({
                      ...formData,
                      triggerType: next,
                      triggerTypeOther: next === "Other" ? formData.triggerTypeOther : "",
                    });
                  }}
                  className="w-full px-4 py-2 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-secondary/30 text-sm bg-white"
                >
                  <option value="Deadline Breach">Deadline Breach</option>
                  <option value="Missing Docs">Missing Docs</option>
                  <option value="Stuck Case">Stuck Case</option>
                  <option value="Payment Issue">Payment Issue</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              {formData.triggerType === "Other" && (
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1">
                    Specify {'"Other"'} <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.triggerTypeOther}
                    onChange={(e) => setFormData({ ...formData, triggerTypeOther: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-secondary/30 text-sm bg-white"
                    placeholder="e.g. Communication breakdown, Partner delay, Wrong visa type..."
                    required
                  />
                  <p className="mt-1 text-xs text-gray-500">Short label so the team knows which kind of escalation this is.</p>
                </div>
              )}
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Related Case ID</label>
                <input
                  type="text"
                  value={formData.relatedCaseId}
                  onChange={(e) => setFormData({ ...formData, relatedCaseId: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-secondary/30 text-sm"
                  placeholder="Related case ID (optional)"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Notes</label>
                <textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-secondary/30 text-sm resize-none"
                  rows={2}
                  placeholder="Additional notes (optional)"
                />
              </div>
              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="flex-1 px-4 py-2.5 text-sm font-bold text-gray-600 bg-gray-100 border border-gray-200 rounded-xl hover:bg-gray-200 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={creating}
                  className="flex-1 px-4 py-2.5 text-sm font-bold text-white bg-secondary border border-secondary rounded-xl hover:bg-secondary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {creating ? (
                    <>
                      <Loader2 size={16} className="animate-spin" />
                      Creating...
                    </>
                  ) : (
                    "Create Escalation"
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showEditModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
              <h2 className="text-lg font-black text-secondary">Edit Escalation</h2>
              <button
                onClick={() => setShowEditModal(false)}
                className="p-2 rounded-lg text-gray-400 hover:text-gray-600 hover:bg-gray-100 transition-colors"
              >
                <X size={20} />
              </button>
            </div>
            <form onSubmit={handleUpdateEscalation} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Case ID</label>
                <select
                  value={formData.caseId}
                  onChange={(e) => handleCaseChange(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-secondary/30 text-sm bg-white"
                  required
                >
                  <option value="">Select a case</option>
                  {cases.map((c) => (
                    <option key={c.caseId} value={c.caseId}>
                      {c.caseId} — {c.candidate ? `${c.candidate.first_name} ${c.candidate.last_name}` : 'Unknown'}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Candidate Name</label>
                <input
                  type="text"
                  value={formData.candidate}
                  onChange={(e) => setFormData({ ...formData, candidate: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-secondary/30 text-sm bg-gray-50"
                  placeholder="Auto-populated from case selection"
                  readOnly
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Severity</label>
                <select
                  value={formData.severity}
                  onChange={(e) => setFormData({ ...formData, severity: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-secondary/30 text-sm bg-white"
                >
                  <option value="Critical">Critical</option>
                  <option value="High">High</option>
                  <option value="Medium">Medium</option>
                  <option value="Low">Low</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Trigger Reason</label>
                <textarea
                  value={formData.trigger}
                  onChange={(e) => setFormData({ ...formData, trigger: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-secondary/30 text-sm resize-none"
                  rows={3}
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Trigger Type</label>
                <select
                  value={formData.triggerType}
                  onChange={(e) => {
                    const next = e.target.value;
                    setFormData({
                      ...formData,
                      triggerType: next,
                      triggerTypeOther: next === "Other" ? formData.triggerTypeOther : "",
                    });
                  }}
                  className="w-full px-4 py-2 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-secondary/30 text-sm bg-white"
                >
                  <option value="Deadline Breach">Deadline Breach</option>
                  <option value="Missing Docs">Missing Docs</option>
                  <option value="Stuck Case">Stuck Case</option>
                  <option value="Payment Issue">Payment Issue</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              {formData.triggerType === "Other" && (
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1">
                    Specify {'"Other"'} <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.triggerTypeOther}
                    onChange={(e) => setFormData({ ...formData, triggerTypeOther: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-secondary/30 text-sm bg-white"
                    placeholder="e.g. Communication breakdown, Partner delay, Wrong visa type..."
                    required
                  />
                  <p className="mt-1 text-xs text-gray-500">Short label so the team knows which kind of escalation this is.</p>
                </div>
              )}
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Related Case ID</label>
                <input
                  type="text"
                  value={formData.relatedCaseId}
                  onChange={(e) => setFormData({ ...formData, relatedCaseId: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-secondary/30 text-sm"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Notes</label>
                <textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-secondary/30 text-sm resize-none"
                  rows={2}
                />
              </div>
              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowEditModal(false)}
                  className="flex-1 px-4 py-2.5 text-sm font-bold text-gray-600 bg-gray-100 border border-gray-200 rounded-xl hover:bg-gray-200 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={updating}
                  className="flex-1 px-4 py-2.5 text-sm font-bold text-white bg-secondary border border-secondary rounded-xl hover:bg-secondary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {updating ? (
                    <>
                      <Loader2 size={16} className="animate-spin" />
                      Updating...
                    </>
                  ) : (
                    "Update Escalation"
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showAssignModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
              <h2 className="text-lg font-black text-secondary">Assign Escalation</h2>
              <button
                onClick={() => setShowAssignModal(false)}
                className="p-2 rounded-lg text-gray-400 hover:text-gray-600 hover:bg-gray-100 transition-colors"
              >
                <X size={20} />
              </button>
            </div>
            <form onSubmit={handleAssignEscalation} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Assign to Admin</label>
                <select
                  value={assignData.assignedAdminId || ""}
                  onChange={(e) => setAssignData({ ...assignData, assignedAdminId: e.target.value ? parseInt(e.target.value) : null })}
                  className="w-full px-4 py-2 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-secondary/30 text-sm bg-white"
                  required
                >
                  <option value="">Select an admin</option>
                  {admins.map((admin) => (
                    <option key={admin.id} value={admin.id}>
                      {admin.first_name} {admin.last_name}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAssignModal(false)}
                  className="flex-1 px-4 py-2.5 text-sm font-bold text-gray-600 bg-gray-100 border border-gray-200 rounded-xl hover:bg-gray-200 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={assigning}
                  className="flex-1 px-4 py-2.5 text-sm font-bold text-white bg-secondary border border-secondary rounded-xl hover:bg-secondary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {assigning ? (
                    <>
                      <Loader2 size={16} className="animate-spin" />
                      Assigning...
                    </>
                  ) : (
                    "Assign"
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </motion.div>
  );
};

export default AdminEscalations;
