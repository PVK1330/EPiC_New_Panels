import React, { useState } from 'react';
import {
  RiHistoryLine,
  RiSearchLine,
  RiFilter3Line,
  RiDownload2Line,
  RiShieldUserLine,
  RiOrganizationChart,
  RiMoneyPoundCircleLine,
  RiDatabase2Line,
  RiLoginCircleLine,
} from 'react-icons/ri';

const SuperadminAuditLog = () => {
  const [activeTab, setActiveTab] = useState('All');

  const logs = [
    { id: 1, type: 'Security', action: 'New Admin Login', user: 'admin@elitevisa.com', org: 'Elite Visa', time: '2026-05-08 10:45', status: 'Success', icon: RiLoginCircleLine, color: 'blue' },
    { id: 2, type: 'Org', action: 'Plan Upgraded (Starter → Pro)', user: 'superadmin', org: 'Global Migrate', time: '2026-05-08 09:30', status: 'Success', icon: RiOrganizationChart, color: 'purple' },
    { id: 3, type: 'Billing', action: 'Payment Processed £349', user: 'System', org: 'Westminster Agency', time: '2026-05-08 00:05', status: 'Success', icon: RiMoneyPoundCircleLine, color: 'green' },
    { id: 4, type: 'Data', action: 'Bulk Upload (540 Records)', user: 'staff@londonlegal.com', org: 'London Legal', time: '2026-05-07 16:20', status: 'Success', icon: RiDatabase2Line, color: 'orange' },
    { id: 5, type: 'Security', action: 'Failed 2FA Attempt', user: 'user@bridgeuk.com', org: 'Bridge UK', time: '2026-05-07 14:15', status: 'Failed', icon: RiShieldUserLine, color: 'red' },
    { id: 6, type: 'Org', action: 'Organization Suspended', user: 'superadmin', org: 'Test Corp', time: '2026-05-07 11:00', status: 'Success', icon: RiFilter3Line, color: 'gray' },
  ];

  const tabs = ['All Events', 'Authentication', 'Org Changes', 'Data Changes', 'Billing'];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-secondary tracking-tight text-primary">Global Audit Trail</h1>
          <p className="text-gray-500 font-bold mt-1 uppercase text-xs tracking-widest">Platform-wide activity monitoring</p>
        </div>
        <button className="flex items-center gap-2 bg-white border border-gray-100 text-secondary px-6 py-3 rounded-2xl font-black text-sm shadow-sm hover:bg-gray-50 transition-all uppercase tracking-tight">
          <RiDownload2Line size={20} />
          Export Global Log
        </button>
      </div>

      {/* Tabs & Search */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex bg-white p-1 rounded-2xl border border-gray-100 shadow-sm overflow-x-auto no-scrollbar">
          {tabs.map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-6 py-2.5 rounded-xl text-xs font-black transition-all uppercase tracking-tight whitespace-nowrap ${
                activeTab === tab
                  ? 'bg-primary text-white shadow-lg shadow-primary/20'
                  : 'text-gray-400 hover:text-secondary'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <div className="relative flex-1 lg:w-80">
            <RiSearchLine className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input
              type="text"
              placeholder="Search by user or org..."
              className="pl-12 pr-6 py-3 bg-white border border-gray-100 rounded-2xl text-sm font-bold w-full focus:ring-2 focus:ring-primary/20 transition-all shadow-sm"
            />
          </div>
          <button className="p-3 bg-white text-gray-400 hover:text-secondary rounded-2xl border border-gray-100 shadow-sm transition-all">
            <RiFilter3Line size={20} />
          </button>
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="bg-white rounded-[40px] border border-gray-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-gray-50/50">
                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Event Type</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Action Performed</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Organisation</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Performed By</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Timestamp</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {logs.map((log) => (
                <tr key={log.id} className="hover:bg-gray-50/30 transition-colors">
                  <td className="px-8 py-5">
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-lg bg-${log.color}-500 bg-opacity-10 text-${log.color === 'secondary' ? 'primary' : log.color + '-600'}`}>
                        <log.icon size={18} />
                      </div>
                      <span className="text-[10px] font-black text-secondary uppercase tracking-tight">{log.type}</span>
                    </div>
                  </td>
                  <td className="px-8 py-5">
                    <p className="text-sm font-black text-secondary uppercase tracking-tight">{log.action}</p>
                  </td>
                  <td className="px-8 py-5">
                    <span className="px-3 py-1.5 bg-gray-100 text-primary text-[10px] font-black rounded-lg border border-gray-200 uppercase tracking-tighter shadow-sm">
                      {log.org}
                    </span>
                  </td>
                  <td className="px-8 py-5 font-bold text-xs text-gray-500 uppercase tracking-tighter">{log.user}</td>
                  <td className="px-8 py-5 font-bold text-xs text-gray-400 uppercase tracking-widest">{log.time}</td>
                  <td className="px-8 py-5">
                    <span className={`px-2 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest border ${
                      log.status === 'Success' ? 'bg-green-50 text-green-600 border-green-100' : 'bg-red-50 text-red-600 border-red-100'
                    }`}>
                      {log.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="p-8 border-t border-gray-50 bg-gray-50/20 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Org Filter:</label>
            <select className="bg-white border border-gray-100 rounded-xl px-4 py-2 text-[10px] font-black uppercase text-secondary shadow-sm outline-none">
              <option>All Organisations</option>
              <option>Elite Visa Solutions</option>
              <option>Global Migrate Pro</option>
            </select>
          </div>
          <div className="flex gap-2">
            <button className="px-6 py-2.5 rounded-xl text-[10px] font-black bg-white border border-gray-100 text-gray-400 uppercase tracking-widest shadow-sm">Prev</button>
            <button className="px-6 py-2.5 rounded-xl text-[10px] font-black bg-primary text-white uppercase tracking-widest shadow-lg shadow-primary/20">Next</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SuperadminAuditLog;
