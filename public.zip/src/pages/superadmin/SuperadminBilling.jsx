import React from 'react';
import { motion } from 'framer-motion';
import {
  RiBillLine,
  RiDownload2Line,
  RiInformationLine,
  RiMore2Line,
  RiExchangeLine,
  RiCheckDoubleLine,
} from 'react-icons/ri';

const SuperadminBilling = () => {
  const plans = [
    { id: 'starter', title: 'Starter', price: '149', users: '5 Users', cases: '500 Cases', storage: '20GB', color: 'blue' },
    { id: 'pro', title: 'Pro', price: '349', users: '20 Users', cases: '2000 Cases', storage: '100GB', color: 'purple' },
    { id: 'enterprise', title: 'Enterprise', price: '799', users: 'Unlimited', cases: 'Unlimited', storage: 'Custom', color: 'secondary' },
  ];

  const orgBilling = [
    { org: 'Elite Visa Solutions', plan: 'Enterprise', amount: '£799', date: 'June 12, 2026', status: 'Paid' },
    { org: 'Global Migrate Pro', plan: 'Pro', amount: '£349', date: 'June 05, 2026', status: 'Pending' },
    { org: 'London Legal Partners', plan: 'Starter', amount: '£0', date: 'May 28, 2026', status: 'Trial' },
    { org: 'Bridge UK Immigration', plan: 'Enterprise', amount: '£799', date: 'May 12, 2026', status: 'Overdue' },
    { org: 'Westminster Agency', plan: 'Pro', amount: '£349', date: 'May 08, 2026', status: 'Paid' },
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-black text-secondary tracking-tight">Billing & Plans</h1>
        <p className="text-gray-500 font-bold mt-1 uppercase text-xs tracking-widest text-primary">Platform Monetization Control</p>
      </div>

      {/* Plan Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {plans.map((plan) => (
          <div key={plan.id} className="bg-white p-8 rounded-[40px] border border-gray-100 shadow-sm relative overflow-hidden group">
            <div className={`absolute top-0 right-0 w-32 h-32 bg-${plan.color}-500 opacity-[0.03] rounded-bl-full group-hover:scale-110 transition-transform`} />
            <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest mb-4">{plan.title} Plan</h3>
            <div className="flex items-baseline gap-1 mb-6">
              <span className="text-4xl font-black text-secondary">£{plan.price}</span>
              <span className="text-sm font-bold text-gray-400 uppercase">/org/month</span>
            </div>
            <div className="space-y-4 mb-8">
              <div className="flex items-center gap-3">
                <RiCheckDoubleLine className={`text-${plan.color === 'secondary' ? 'primary' : plan.color + '-500'}`} size={20} />
                <span className="text-xs font-black text-secondary uppercase tracking-tight">{plan.users}</span>
              </div>
              <div className="flex items-center gap-3">
                <RiCheckDoubleLine className={`text-${plan.color === 'secondary' ? 'primary' : plan.color + '-500'}`} size={20} />
                <span className="text-xs font-black text-secondary uppercase tracking-tight">{plan.cases}</span>
              </div>
              <div className="flex items-center gap-3">
                <RiCheckDoubleLine className={`text-${plan.color === 'secondary' ? 'primary' : plan.color + '-500'}`} size={20} />
                <span className="text-xs font-black text-secondary uppercase tracking-tight">{plan.storage} Storage</span>
              </div>
            </div>
            <button className={`w-full py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest border border-gray-100 hover:bg-gray-50 transition-all text-secondary`}>
              Edit Features & Price
            </button>
          </div>
        ))}
      </div>

      {/* Org Billing Status Table */}
      <div className="bg-white rounded-[40px] border border-gray-100 shadow-sm overflow-hidden">
        <div className="p-8 border-b border-gray-50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <RiBillLine className="text-primary" size={24} />
            <h3 className="font-black text-secondary uppercase tracking-tight">Organisation Billing Status</h3>
          </div>
          <button className="text-xs font-black text-primary hover:underline uppercase tracking-widest">Download Report</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-gray-50/50">
                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Organisation</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Current Plan</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Billing Amount</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Renewal Date</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Status</th>
                <th className="px-8 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">Invoices</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {orgBilling.map((item, idx) => (
                <tr key={idx} className="hover:bg-gray-50/30 transition-colors">
                  <td className="px-8 py-5 font-black text-secondary text-sm">{item.org}</td>
                  <td className="px-8 py-5">
                    <span className={`px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-tight ${
                      item.plan === 'Enterprise' ? 'bg-purple-100 text-purple-600' :
                      item.plan === 'Pro' ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-600'
                    }`}>
                      {item.plan}
                    </span>
                  </td>
                  <td className="px-8 py-5 font-bold text-sm text-secondary">{item.amount}</td>
                  <td className="px-8 py-5 font-bold text-xs text-gray-400 uppercase">{item.date}</td>
                  <td className="px-8 py-5">
                    <span className={`flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest ${
                      item.status === 'Paid' ? 'text-green-500' :
                      item.status === 'Pending' ? 'text-blue-500' :
                      item.status === 'Trial' ? 'text-purple-500' : 'text-red-500'
                    }`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${
                        item.status === 'Paid' ? 'bg-green-500' :
                        item.status === 'Pending' ? 'bg-blue-500' :
                        item.status === 'Trial' ? 'bg-purple-500' : 'bg-red-500'
                      }`} />
                      {item.status}
                    </span>
                  </td>
                  <td className="px-8 py-5 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button className="p-2.5 bg-gray-50 text-gray-400 hover:text-primary hover:bg-primary/5 rounded-xl transition-all shadow-sm">
                        <RiDownload2Line size={18} />
                      </button>
                      <button className="p-2.5 bg-gray-50 text-gray-400 hover:text-secondary hover:bg-gray-200 rounded-xl transition-all shadow-sm">
                        <RiMore2Line size={18} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="p-8 border-t border-gray-50 bg-gray-50/20">
          <div className="flex items-start gap-3 p-4 bg-blue-50 border border-blue-100 rounded-2xl">
            <RiInformationLine className="text-blue-500 mt-0.5" size={20} />
            <div>
              <p className="text-xs font-black text-blue-900 uppercase tracking-tight">Automated Invoicing</p>
              <p className="text-[10px] font-bold text-blue-700 mt-1 uppercase tracking-tighter">
                System generates invoices on the 1st of every month. Failed payments automatically trigger organization suspension after 7 days.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SuperadminBilling;
