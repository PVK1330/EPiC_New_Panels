import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  RiAddLine,
  RiSettings4Line,
  RiCheckLine,
  RiCloseLine,
  RiLayoutMasonryLine,
  RiMoneyPoundCircleLine,
  RiGroupLine,
  RiShieldFlashLine,
  RiInformationLine,
} from 'react-icons/ri';
import Button from '../../components/Button';
import Input from '../../components/Input';

const AVAILABLE_MODULES = [
  { id: 'dashboard', name: 'Dashboard', icon: RiLayoutMasonryLine, description: 'Main analytics and overview' },
  { id: 'cases', name: 'Case Management', icon: RiShieldFlashLine, description: 'Manage and track visa applications' },
  { id: 'documents', name: 'Document Vault', icon: RiSettings4Line, description: 'Secure document storage and verification' },
  { id: 'finance', name: 'Finance & Invoices', icon: RiMoneyPoundCircleLine, description: 'Billing and payment tracking' },
  { id: 'reporting', name: 'Advanced Reporting', icon: RiSettings4Line, description: 'Custom reports and exports' },
  { id: 'team', name: 'Team Management', icon: RiGroupLine, description: 'Manage caseworkers and staff' },
];

const SuperadminPlans = () => {
  const [plans, setPlans] = useState([
    { id: 1, name: 'Starter', price: 99, interval: 'month', modules: ['dashboard', 'cases'], status: 'Active' },
    { id: 2, name: 'Professional', price: 299, interval: 'month', modules: ['dashboard', 'cases', 'documents', 'team'], status: 'Active' },
    { id: 3, name: 'Enterprise', price: 599, interval: 'month', modules: ['dashboard', 'cases', 'documents', 'finance', 'reporting', 'team'], status: 'Active' },
  ]);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    price: '',
    interval: 'month',
    selectedModules: [],
  });

  const toggleModule = (moduleId) => {
    setFormData(prev => ({
      ...prev,
      selectedModules: prev.selectedModules.includes(moduleId)
        ? prev.selectedModules.filter(id => id !== moduleId)
        : [...prev.selectedModules, moduleId]
    }));
  };

  const handleCreatePlan = () => {
    const newPlan = {
      id: Date.now(),
      name: formData.name,
      price: formData.price,
      interval: formData.interval,
      modules: formData.selectedModules,
      status: 'Active'
    };
    setPlans([...plans, newPlan]);
    setIsModalOpen(false);
    setFormData({ name: '', price: '', interval: 'month', selectedModules: [] });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-secondary tracking-tight">Subscription Plans</h1>
          <p className="text-gray-500 font-bold mt-1 uppercase text-xs tracking-widest">Define platform tiers and module access</p>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 bg-primary text-white px-6 py-3 rounded-2xl font-black text-sm shadow-lg shadow-primary/20 hover:scale-105 transition-all uppercase tracking-tight"
        >
          <RiAddLine size={20} />
          Create New Plan
        </button>
      </div>

      {/* Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {plans.map((plan) => (
          <motion.div
            key={plan.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white p-8 rounded-[40px] border border-gray-100 shadow-sm hover:shadow-md transition-all group"
          >
            <div className="flex justify-between items-start mb-6">
              <div className="w-14 h-14 bg-gray-50 rounded-2xl flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-all">
                <RiShieldFlashLine size={28} />
              </div>
              <span className="px-3 py-1 bg-green-50 text-green-600 text-[10px] font-black uppercase rounded-lg border border-green-100">
                {plan.status}
              </span>
            </div>
            
            <h3 className="text-2xl font-black text-secondary tracking-tight mb-2">{plan.name}</h3>
            <div className="flex items-baseline gap-1 mb-8">
              <span className="text-4xl font-black text-secondary">£{plan.price}</span>
              <span className="text-gray-400 font-bold text-xs uppercase tracking-widest">/ {plan.interval}</span>
            </div>

            <div className="space-y-4">
              <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Included Modules</p>
              <div className="space-y-3">
                {AVAILABLE_MODULES.map((module) => (
                  <div key={module.id} className={`flex items-center gap-3 ${plan.modules.includes(module.id) ? 'text-secondary' : 'text-gray-300'}`}>
                    <div className={`w-5 h-5 rounded-full flex items-center justify-center ${plan.modules.includes(module.id) ? 'bg-primary/10 text-primary' : 'bg-gray-50 text-gray-300'}`}>
                      <RiCheckLine size={12} />
                    </div>
                    <span className="text-sm font-bold">{module.name}</span>
                  </div>
                ))}
              </div>
            </div>

            <button className="w-full mt-10 py-4 bg-gray-50 text-secondary rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-gray-100 transition-all border border-gray-100">
              Edit Plan Details
            </button>
          </motion.div>
        ))}
      </div>

      {/* Create Plan Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="absolute inset-0 bg-secondary/40 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative bg-white w-full max-w-3xl rounded-[40px] shadow-2xl overflow-hidden border border-gray-100"
            >
              <div className="p-8 border-b border-gray-50 flex items-center justify-between bg-gray-50/50">
                <div>
                  <h2 className="text-2xl font-black text-secondary tracking-tight">Create Subscription Plan</h2>
                  <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mt-1">Configure pricing and module access</p>
                </div>
                <button onClick={() => setIsModalOpen(false)} className="p-2 text-gray-400 hover:text-secondary bg-white rounded-2xl shadow-sm border border-gray-100 transition-all">
                  <RiCloseLine size={24} />
                </button>
              </div>

              <div className="p-8 overflow-y-auto max-h-[70vh] custom-scrollbar">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                  <Input 
                    label="Plan Name" 
                    placeholder="e.g. Premium Business" 
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                  />
                  <div className="grid grid-cols-2 gap-4">
                    <Input 
                      label="Price (£)" 
                      type="number" 
                      placeholder="299"
                      value={formData.price}
                      onChange={(e) => setFormData({...formData, price: e.target.value})}
                    />
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Interval</label>
                      <select 
                        className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-2xl text-sm font-bold text-secondary focus:ring-2 focus:ring-primary/20 outline-none appearance-none"
                        value={formData.interval}
                        onChange={(e) => setFormData({...formData, interval: e.target.value})}
                      >
                        <option value="month">Monthly</option>
                        <option value="year">Yearly</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <p className="text-[11px] font-black text-gray-400 uppercase tracking-widest">Select Modules to Include</p>
                    <span className="text-[10px] font-bold text-primary bg-primary/5 px-2 py-1 rounded-lg">
                      {formData.selectedModules.length} Modules Selected
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {AVAILABLE_MODULES.map((module) => (
                      <div 
                        key={module.id}
                        onClick={() => toggleModule(module.id)}
                        className={`p-4 rounded-3xl border-2 cursor-pointer transition-all flex gap-4 ${
                          formData.selectedModules.includes(module.id)
                            ? 'border-primary bg-primary/5'
                            : 'border-gray-50 hover:border-gray-100'
                        }`}
                      >
                        <div className={`w-12 h-12 rounded-2xl shrink-0 flex items-center justify-center ${
                          formData.selectedModules.includes(module.id) ? 'bg-primary text-white' : 'bg-gray-100 text-gray-400'
                        }`}>
                          <module.icon size={24} />
                        </div>
                        <div>
                          <h4 className="font-black text-secondary text-sm">{module.name}</h4>
                          <p className="text-[10px] font-bold text-gray-400 uppercase leading-tight mt-1">{module.description}</p>
                        </div>
                        {formData.selectedModules.includes(module.id) && (
                          <RiCheckLine size={20} className="text-primary ml-auto" />
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-8 p-4 bg-orange-50 rounded-2xl border border-orange-100 flex gap-3">
                  <RiInformationLine className="text-orange-500 shrink-0" size={20} />
                  <p className="text-[10px] font-bold text-orange-700 leading-relaxed uppercase">
                    Changes to plan modules will affect all existing organizations currently subscribed to this plan. Proceed with caution.
                  </p>
                </div>
              </div>

              <div className="p-8 border-t border-gray-50 bg-gray-50/30 flex items-center justify-end gap-4">
                <button 
                  onClick={() => setIsModalOpen(false)}
                  className="px-8 py-3 rounded-2xl font-black text-xs text-gray-500 hover:text-secondary uppercase tracking-widest transition-all"
                >
                  Cancel
                </button>
                <Button onClick={handleCreatePlan} className="px-10">
                  Save Plan Config
                </Button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default SuperadminPlans;
