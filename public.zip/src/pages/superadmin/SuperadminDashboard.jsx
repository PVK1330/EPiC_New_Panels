import React from 'react';
import { motion } from 'framer-motion';
import {
  RiOrganizationChart,
  RiGroupLine,
  RiBriefcaseLine,
  RiMoneyPoundCircleLine,
  RiTimeLine,
  RiErrorWarningLine,
  RiArrowRightUpLine,
  RiGlobalLine,
  RiHistoryLine,
} from 'react-icons/ri';

const StatCard = ({ title, value, icon: Icon, trend, color }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow"
  >
    <div className="flex items-start justify-between mb-4">
      <div className={`p-3 rounded-2xl ${color} bg-opacity-10 text-${color.split('-')[1]}-600`}>
        <Icon size={24} />
      </div>
      {trend && (
        <div className="flex items-center gap-1 text-green-500 text-xs font-black">
          <RiArrowRightUpLine />
          {trend}
        </div>
      )}
    </div>
    <p className="text-gray-500 text-xs font-black uppercase tracking-widest mb-1">{title}</p>
    <h3 className="text-2xl font-black text-secondary">{value}</h3>
  </motion.div>
);

const SuperadminDashboard = () => {
  const orgs = [
    { name: 'Elite Visa Solutions', plan: 'Enterprise', users: 45, cases: 1240, status: 'Active' },
    { name: 'Global Migrate Pro', plan: 'Pro', users: 12, cases: 450, status: 'Active' },
    { name: 'London Legal Partners', plan: 'Starter', users: 4, cases: 85, status: 'Trial' },
    { name: 'Bridge UK Immigration', plan: 'Enterprise', users: 38, cases: 980, status: 'Suspended' },
    { name: 'Westminster Agency', plan: 'Pro', users: 15, cases: 310, status: 'Active' },
  ];

  const auditEvents = [
    { id: 1, type: 'Auth', desc: 'New Admin login', org: 'Elite Visa', time: '2 mins ago' },
    { id: 2, type: 'Billing', desc: 'Plan upgraded to Enterprise', org: 'Global Migrate', time: '15 mins ago' },
    { id: 3, type: 'Data', desc: 'Bulk import of 500 cases', org: 'London Legal', time: '1 hour ago' },
    { id: 4, type: 'System', desc: 'New organization onboarded', org: 'System', time: '3 hours ago' },
    { id: 5, type: 'Security', desc: 'Failed login attempt (IP: 192.168.1.1)', org: 'Bridge UK', time: '5 hours ago' },
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-secondary">System Overview</h1>
          <p className="text-gray-500 font-bold mt-1">Platform-wide analytics and control</p>
        </div>
        <div className="flex items-center gap-2 bg-white px-4 py-2 rounded-2xl border border-gray-100 shadow-sm">
          <RiGlobalLine className="text-primary" />
          <span className="text-sm font-black text-secondary uppercase">Global Node: London-1</span>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <StatCard title="Total Orgs" value="124" icon={RiOrganizationChart} trend="+12%" color="bg-blue-500" />
        <StatCard title="Active Users" value="2,840" icon={RiGroupLine} trend="+5.4%" color="bg-purple-500" />
        <StatCard title="Active Cases" value="15,200" icon={RiBriefcaseLine} trend="+8.2%" color="bg-orange-500" />
        <StatCard title="Monthly Rev" value="£84,250" icon={RiMoneyPoundCircleLine} trend="+15%" color="bg-green-500" />
        <StatCard title="Overdue" value="42" icon={RiErrorWarningLine} color="bg-red-500" />
        <StatCard title="Pending" value="8" icon={RiTimeLine} color="bg-yellow-500" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Organisations Table Preview */}
        <div className="lg:col-span-2 bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-gray-50 flex items-center justify-between">
            <h3 className="font-black text-secondary uppercase tracking-tight">Organisations at a Glance</h3>
            <button className="text-xs font-black text-primary hover:underline uppercase">View All</button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-gray-50/50">
                  <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Organisation</th>
                  <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Plan</th>
                  <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest text-center">Users</th>
                  <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest text-center">Cases</th>
                  <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest">Status</th>
                  <th className="px-6 py-4 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {orgs.map((org) => (
                  <tr key={org.name} className="hover:bg-gray-50/50 transition-colors">
                    <td className="px-6 py-4 font-black text-secondary text-sm">{org.name}</td>
                    <td className="px-6 py-4">
                      <span className={`px-2.5 py-1 rounded-lg text-[10px] font-black uppercase ${
                        org.plan === 'Enterprise' ? 'bg-purple-100 text-purple-600' :
                        org.plan === 'Pro' ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-600'
                      }`}>
                        {org.plan}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-center font-bold text-sm text-gray-500">{org.users}</td>
                    <td className="px-6 py-4 text-center font-bold text-sm text-gray-500">{org.cases}</td>
                    <td className="px-6 py-4">
                      <span className={`flex items-center gap-1.5 text-[10px] font-black uppercase ${
                        org.status === 'Active' ? 'text-green-500' :
                        org.status === 'Trial' ? 'text-blue-500' : 'text-red-500'
                      }`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${
                          org.status === 'Active' ? 'bg-green-500' :
                          org.status === 'Trial' ? 'bg-blue-500' : 'bg-red-500'
                        }`} />
                        {org.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button className="text-[10px] font-black text-primary hover:bg-primary/5 px-3 py-1 rounded-lg border border-primary/20 transition-all uppercase">
                        Manage
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Audit Log Preview */}
        <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden flex flex-col">
          <div className="p-6 border-b border-gray-50 flex items-center justify-between">
            <h3 className="font-black text-secondary uppercase tracking-tight">Global Audit Log</h3>
            <button className="text-xs font-black text-primary hover:underline uppercase">Full Log</button>
          </div>
          <div className="flex-1 p-4 space-y-4">
            {auditEvents.map((event) => (
              <div key={event.id} className="flex gap-4 p-3 rounded-2xl hover:bg-gray-50 transition-colors border border-transparent hover:border-gray-100">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                  event.type === 'Auth' ? 'bg-blue-100 text-blue-600' :
                  event.type === 'Billing' ? 'bg-green-100 text-green-600' :
                  event.type === 'Data' ? 'bg-orange-100 text-orange-600' : 'bg-gray-100 text-gray-600'
                }`}>
                  <RiHistoryLine size={20} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{event.type}</span>
                    <span className="text-[10px] font-bold text-gray-400">{event.time}</span>
                  </div>
                  <p className="text-xs font-bold text-secondary truncate mt-0.5">{event.desc}</p>
                  <p className="text-[10px] font-black text-primary uppercase mt-1">{event.org}</p>
                </div>
              </div>
            ))}
          </div>
          {/* Plan Distribution Placeholder */}
          <div className="p-6 border-t border-gray-50 bg-gray-50/50">
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Plan Distribution</h4>
            </div>
            <div className="flex h-3 rounded-full overflow-hidden">
              <div className="w-[45%] bg-purple-500" title="Enterprise: 45%" />
              <div className="w-[35%] bg-blue-500" title="Pro: 35%" />
              <div className="w-[20%] bg-gray-300" title="Starter: 20%" />
            </div>
            <div className="flex gap-4 mt-3">
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-purple-500" />
                <span className="text-[10px] font-bold text-gray-500">Enterprise</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-blue-500" />
                <span className="text-[10px] font-bold text-gray-500">Pro</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-gray-300" />
                <span className="text-[10px] font-bold text-gray-500">Starter</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SuperadminDashboard;
