import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  RiSearchLine,
  RiFilter3Line,
  RiAddLine,
  RiMore2Line,
  RiBuilding2Line,
  RiShieldCheckLine,
  RiErrorWarningLine,
  RiExchangeLine,
} from 'react-icons/ri';
import CreateOrganisationModal from '../../components/superadmin/CreateOrganisationModal';

const SuperadminOrganisations = () => {
  const [activeTab, setActiveTab] = useState('All');
  const [isModalOpen, setIsModalOpen] = useState(false);

  const orgs = [
    { id: 1, name: 'Elite Visa Solutions', slug: 'elite-visa', plan: 'Enterprise', users: 45, cases: 1240, storage: '4.2 GB', status: 'Active', country: 'United Kingdom' },
    { id: 2, name: 'Global Migrate Pro', slug: 'global-migrate', plan: 'Pro', users: 12, cases: 450, storage: '1.1 GB', status: 'Active', country: 'Canada' },
    { id: 3, name: 'London Legal Partners', slug: 'london-legal', plan: 'Starter', users: 4, cases: 85, storage: '250 MB', status: 'Trial', country: 'United Kingdom' },
    { id: 4, name: 'Bridge UK Immigration', slug: 'bridge-uk', plan: 'Enterprise', users: 38, cases: 980, storage: '3.8 GB', status: 'Suspended', country: 'United Kingdom' },
    { id: 5, name: 'Westminster Agency', slug: 'westminster', plan: 'Pro', users: 15, cases: 310, storage: '800 MB', status: 'Active', country: 'United Kingdom' },
    { id: 6, name: 'Dubai Visa Experts', slug: 'dubai-visa', plan: 'Pro', users: 8, cases: 210, storage: '450 MB', status: 'Active', country: 'UAE' },
    { id: 7, name: 'Sydney Migrate', slug: 'sydney-migrate', plan: 'Starter', users: 2, cases: 45, storage: '120 MB', status: 'Trial', country: 'Australia' },
  ];

  const tabs = ['All', 'Active', 'Trial', 'Suspended'];

  const filteredOrgs = activeTab === 'All' ? orgs : orgs.filter(org => org.status === activeTab);

  const handleCreateOrg = (data) => {
    console.log('Creating Org:', data);
    setIsModalOpen(false);
    // Here we would call the API
  };

  return (
    <div className="space-y-6">
      <CreateOrganisationModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        onSubmit={handleCreateOrg}
      />
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-secondary tracking-tight">Organisations</h1>
          <p className="text-gray-500 font-bold mt-1 uppercase text-xs tracking-widest">Managing {orgs.length} total entities</p>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 bg-primary text-white px-6 py-3 rounded-2xl font-black text-sm shadow-lg shadow-primary/20 hover:scale-105 transition-all uppercase tracking-tight"
        >
          <RiAddLine size={20} />
          Create Organisation
        </button>
      </div>

      {/* Filters & Search */}
      <div className="bg-white p-4 rounded-3xl border border-gray-100 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex bg-gray-50 p-1 rounded-2xl w-fit">
          {tabs.map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-6 py-2 rounded-xl text-xs font-black transition-all uppercase tracking-tight ${
                activeTab === tab
                  ? 'bg-white text-primary shadow-sm'
                  : 'text-gray-400 hover:text-secondary'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <RiSearchLine className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input
              type="text"
              placeholder="Search by name, slug or ID..."
              className="pl-12 pr-6 py-3 bg-gray-50 border-none rounded-2xl text-sm font-bold w-full md:w-80 focus:ring-2 focus:ring-primary/20 transition-all"
            />
          </div>
          <button className="p-3 bg-gray-50 text-gray-400 hover:text-secondary rounded-2xl transition-all border border-transparent hover:border-gray-100">
            <RiFilter3Line size={20} />
          </button>
        </div>
      </div>

      {/* Organisations Table */}
      <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-50/50">
                <th className="px-6 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Organisation</th>
                <th className="px-6 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Plan & Billing</th>
                <th className="px-6 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest text-center">Users</th>
                <th className="px-6 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest text-center">Cases</th>
                <th className="px-6 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest text-center">Storage</th>
                <th className="px-6 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest">Status</th>
                <th className="px-6 py-5 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {filteredOrgs.map((org) => (
                <tr key={org.id} className="hover:bg-gray-50/30 transition-colors group">
                  <td className="px-6 py-5">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-gray-100 rounded-2xl flex items-center justify-center text-secondary font-black text-lg group-hover:bg-primary/10 group-hover:text-primary transition-colors">
                        {org.name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-black text-secondary text-sm leading-tight">{org.name}</p>
                        <p className="text-[10px] font-bold text-gray-400 mt-1 uppercase tracking-tight">
                          {org.slug}.epic-crm.com • {org.country}
                        </p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-5">
                    <div className="flex flex-col gap-1.5">
                      <span className={`w-fit px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-tight ${
                        org.plan === 'Enterprise' ? 'bg-purple-100 text-purple-600 border border-purple-200' :
                        org.plan === 'Pro' ? 'bg-blue-100 text-blue-600 border border-blue-200' : 'bg-gray-100 text-gray-600 border border-gray-200'
                      }`}>
                        {org.plan}
                      </span>
                      <p className="text-[10px] font-bold text-gray-400 uppercase tracking-tighter">Renewal: June 12, 2026</p>
                    </div>
                  </td>
                  <td className="px-6 py-5 text-center font-black text-sm text-secondary">{org.users}</td>
                  <td className="px-6 py-5 text-center font-black text-sm text-secondary">{org.cases}</td>
                  <td className="px-6 py-5 text-center font-bold text-xs text-gray-500">{org.storage}</td>
                  <td className="px-6 py-5">
                    <span className={`flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest ${
                      org.status === 'Active' ? 'text-green-500' :
                      org.status === 'Trial' ? 'text-blue-500' : 'text-red-500'
                    }`}>
                      <span className={`w-2 h-2 rounded-full ${
                        org.status === 'Active' ? 'bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.5)]' :
                        org.status === 'Trial' ? 'bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.5)]' : 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.5)]'
                      }`} />
                      {org.status}
                    </span>
                  </td>
                  <td className="px-6 py-5 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button title="Manage Organisation" className="p-2 text-gray-400 hover:text-primary hover:bg-primary/5 rounded-xl transition-all border border-transparent hover:border-primary/10">
                        <RiShieldCheckLine size={20} />
                      </button>
                      <button title="Suspend / Block" className={`p-2 transition-all border border-transparent rounded-xl ${
                        org.status === 'Suspended' ? 'text-green-500 hover:bg-green-50 hover:border-green-100' : 'text-red-400 hover:bg-red-50 hover:border-red-100'
                      }`}>
                        {org.status === 'Suspended' ? <RiExchangeLine size={20} /> : <RiErrorWarningLine size={20} />}
                      </button>
                      <button className="p-2 text-gray-400 hover:text-secondary hover:bg-gray-100 rounded-xl transition-all">
                        <RiMore2Line size={20} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {/* Pagination Placeholder */}
        <div className="p-6 border-t border-gray-50 bg-gray-50/30 flex items-center justify-between">
          <p className="text-xs font-bold text-gray-400 tracking-tight uppercase">Showing 1 to 7 of 124 results</p>
          <div className="flex gap-2">
            <button disabled className="px-4 py-2 rounded-xl text-xs font-black bg-white border border-gray-100 text-gray-300 transition-all uppercase tracking-tight">Prev</button>
            <button className="px-4 py-2 rounded-xl text-xs font-black bg-white border border-gray-100 text-secondary hover:bg-gray-50 transition-all uppercase tracking-tight shadow-sm">Next</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SuperadminOrganisations;
