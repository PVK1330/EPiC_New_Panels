import { useState, useRef, useEffect, useCallback } from "react";
import { Outlet, useNavigate, useLocation, Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { logout } from "../../store/slices/authSlice";
import AdminSidebar from "./AdminSidebar";
import CaseworkerSidebar from "../CaseworkerSidebar";
import BusinessSidebar from "../business/BusinessSidebar";
import CandidateSidebar from "../CandidateSidebar";
import {
  RiMenuLine,
  RiHome5Line,
  RiArrowRightSLine,
  RiSettings3Line,
  RiUserLine,
  RiLogoutBoxRLine,
} from "react-icons/ri";

import NotificationDropdown from "../notifications/NotificationDropdown";
import MessageDropdown from "../notifications/MessageDropdown";
import eliteLogo from "../../assets/elitepic_logo.png";
import { getOrganisationBranding } from "../../services/settingsService";
import { resolveAssetUrl, resolveOrganisationLogoUrl } from "../../utils/assetUrl";
import { getProfileMenuPaths } from "../../utils/authResponse";

const AdminLayout = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);

  const dropdownRef = useRef(null);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();
  const user = useSelector((state) => state.auth.user);
  const profileMenuPaths = getProfileMenuPaths(user);
  const [orgLogoUrl, setOrgLogoUrl] = useState(null);

  const fullName = user?.first_name
    ? `${user?.first_name} ${user?.last_name || ""}`.trim()
    : user?.name || user?.email?.split("@")[0] || "Admin";

  const profilePicUrl =
    user?.profile_pic || user?.avatar_url
      ? resolveAssetUrl(user?.profile_pic || user?.avatar_url)
      : null;

  const fetchOrganisationBranding = useCallback(async () => {
    try {
      const res = await getOrganisationBranding();
      const organisation = res.data?.data?.organisation;
      setOrgLogoUrl(resolveOrganisationLogoUrl(organisation));
    } catch {
      setOrgLogoUrl(null);
    }
  }, []);

  useEffect(() => {
    fetchOrganisationBranding();
    const onBrandingUpdated = () => fetchOrganisationBranding();
    window.addEventListener("organisation-branding-updated", onBrandingUpdated);
    return () =>
      window.removeEventListener(
        "organisation-branding-updated",
        onBrandingUpdated,
      );
  }, [fetchOrganisationBranding]);

  const handleLogout = () => {
    dispatch(logout());
    navigate("/login");
  };

  const closeAll = () => {
    setProfileOpen(false);
  };

  const renderSidebar = () => {
    const props = {
      isOpen: sidebarOpen,
      onClose: () => setSidebarOpen(false),
    };

    switch (user?.role) {
      case "admin":
        return <AdminSidebar {...props} />;
      case "caseworker":
        return <CaseworkerSidebar {...props} />;
      case "business":
        return <BusinessSidebar {...props} />;
      case "candidate":
        return <CandidateSidebar {...props} />;
      default:
        return <AdminSidebar {...props} />;
    }
  };

  const pathnames = location.pathname.split("/").filter((x) => x);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        closeAll();
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div className="flex h-screen bg-surface overflow-hidden">
      {renderSidebar()}

      <div className="flex-1 flex flex-col min-w-0">
        {/* ── Top Bar ── */}
        <header className="h-16 bg-white border-b border-gray-100 flex items-center justify-between px-4 md:px-6 sticky top-0 z-40 shrink-0 shadow-sm gap-3">
          {/* Left: EPiC logo + hamburger + breadcrumb */}
          <div className="flex items-center gap-2 min-w-0 overflow-hidden">
            <Link
              to={`/${user?.role || "admin"}/dashboard`}
              className="shrink-0"
              aria-label="EPiC home"
            >
              {/* <img
                src={eliteLogo}
                alt="EPiC"
                className="h-7 sm:h-8 w-auto object-contain"
              /> */}
            </Link>
            <button
              type="button"
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-2 -ml-1 rounded-xl text-gray-500 hover:bg-gray-100 transition-colors shrink-0"
              aria-label="Open menu"
            >
              <RiMenuLine size={22} />
            </button>

            <nav className="flex items-center text-sm font-medium text-gray-500 overflow-hidden">
              <Link
                to={`/${user?.role || "admin"}/dashboard`}
                className="hover:text-primary transition-colors flex items-center shrink-0"
                aria-label="Home"
              >
                <RiHome5Line size={16} />
              </Link>

              {pathnames.map((value, index) => {
                const last = index === pathnames.length - 1;
                const to = `/${pathnames.slice(0, index + 1).join("/")}`;
                const name =
                  value.charAt(0).toUpperCase() +
                  value.slice(1).replace(/-/g, " ");

                return (
                  <div key={to} className="flex items-center shrink-0">
                    <RiArrowRightSLine
                      size={15}
                      className="mx-1 text-gray-300"
                    />
                    {last ? (
                      <span className="text-secondary font-black truncate max-w-[120px] md:max-w-[200px]">
                        {name}
                      </span>
                    ) : (
                      <Link
                        to={to}
                        className="hover:text-primary transition-colors truncate max-w-[80px] md:max-w-[120px] capitalize"
                      >
                        {name}
                      </Link>
                    )}
                  </div>
                );
              })}
            </nav>
          </div>

          {/* Right: action icons */}
          <div
            ref={dropdownRef}
            className="flex items-center gap-1 md:gap-1.5 ml-4 shrink-0"
          >
            {/* Messages */}
            <MessageDropdown />

            {/* Notifications */}
            <NotificationDropdown />

            {/* Profile */}
            <div className="relative">
              <button
                onClick={() => {
                  setProfileOpen(!profileOpen);
                }}
                className={`flex items-center gap-2 px-2 py-1.5 rounded-xl transition-all ${
                  profileOpen
                    ? "bg-gray-100 ring-2 ring-primary/10"
                    : "hover:bg-gray-50"
                }`}
              >
                <div className="w-8 h-8 bg-primary/10 text-primary rounded-xl flex items-center justify-center font-black text-sm shrink-0 overflow-hidden">
                  {profilePicUrl ? (
                    <img
                      src={profilePicUrl}
                      alt={fullName}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    fullName.charAt(0).toUpperCase()
                  )}
                </div>
                <div className="text-left hidden sm:block">
                  <p className="text-xs font-black text-secondary leading-none">
                    {fullName}
                  </p>
                  <p className="text-[10px] text-gray-400 mt-0.5 uppercase tracking-wide">
                    {user?.role || "Admin"}
                  </p>
                </div>
              </button>

              {profileOpen && (
                <div className="absolute right-0 mt-2 w-52 bg-white border border-gray-100 rounded-2xl shadow-xl overflow-hidden py-1.5 z-50 origin-top-right">
                  <div className="px-4 py-3 border-b border-gray-100 mb-1">
                    <p className="text-sm font-black text-secondary">
                      {fullName}
                    </p>
                    <p className="text-xs text-gray-400 truncate">
                      {user?.email || "admin@elitepic.com"}
                    </p>
                  </div>
                  {profileMenuPaths && (
                    <>
                      <Link
                        to={profileMenuPaths.profile}
                        onClick={() => setProfileOpen(false)}
                        className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-50 hover:text-primary transition-colors"
                      >
                        <RiUserLine size={16} />
                        My Profile
                      </Link>
                      <Link
                        to={profileMenuPaths.settings}
                        onClick={() => setProfileOpen(false)}
                        className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-gray-600 hover:bg-gray-50 hover:text-primary transition-colors"
                      >
                        <RiSettings3Line size={16} />
                        Settings
                      </Link>
                    </>
                  )}
                  <div className="border-t border-gray-100 my-1" />
                  <button
                    onClick={handleLogout}
                    className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-primary hover:bg-primary/5 transition-colors"
                  >
                    <RiLogoutBoxRLine size={16} />
                    Sign Out
                  </button>
                </div>
              )}
            </div>

            {orgLogoUrl && (
              <div className="flex items-center pl-2 ml-1 border-l border-gray-100 shrink-0">
                <img
                  src={orgLogoUrl}
                  alt="Organisation logo"
                  className="max-h-8 sm:max-h-10 max-w-[100px] sm:max-w-[140px] object-contain"
                />
              </div>
            )}
          </div>
        </header>

        {/* ── Main Content ── */}
        <main
          id="main-content"
          className="flex-1 overflow-y-auto p-4 md:p-5 bg-surface"
        >
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;
