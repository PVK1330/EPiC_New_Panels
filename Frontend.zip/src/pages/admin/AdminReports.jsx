import { useState, useMemo, useRef, useEffect, useCallback } from "react";
import {
  FiCalendar,
  FiDownload,
  FiSearch,
  FiChevronLeft,
  FiChevronRight,
  FiX,
  FiEye,
  FiUser,
  FiCheckCircle,
  FiAlertCircle,
  FiClock,
  FiTrendingUp,
  FiTrendingDown,
  FiStar,
  FiFileText,
  FiArrowLeft,
  FiFilter,
  FiLoader,
  FiRefreshCw,
} from "react-icons/fi";
import { RiBarChartLine } from "react-icons/ri";
import SegmentedTabBar from "../../components/admin/SegmentedTabBar";
import Button from "../../components/Button";
import Input from "../../components/Input";
import { useToast } from "../../context/ToastContext";
import { Loader2 } from "lucide-react";
import {
  getReportingSummary,
  getCaseAnalytics,
  getWorkloadReport,
  getFinancialReport,
  getPerformanceReport,
  exportReportingExcel,
} from "../../services/reportingApi";
import { getVisaTypes } from "../../services/settingsService";
import { getDepartments } from "../../services/caseWorker";
import MockDataBanner from "../../components/admin/MockDataBanner";
import {
  MOCK_REPORT_CASE_TYPES,
  MOCK_REPORT_WORKLOAD,
  MOCK_REPORT_FINANCE,
} from "../../data/adminMockData";
import useDownloads from "../../hooks/useDownloads";

// ─── Constants ───────────────────────────────────────────────────────────────

const TABS = [
  { id: "cases", label: "Case Reports" },
  { id: "workload", label: "Workload Reports" },
  { id: "finance", label: "Financial Reports" },
  { id: "performance", label: "Performance Reports" },
];

const MONTH_NAMES = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];
const DAY_NAMES = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];

const tableHead =
  "px-4 py-3 text-[10px] font-black text-gray-400 uppercase tracking-wider whitespace-nowrap";

// ─── Helpers ─────────────────────────────────────────────────────────────────

function formatDate(date) {
  if (!date) return "";
  return date.toLocaleDateString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

function sameDay(a, b) {
  return a && b && a.toDateString() === b.toDateString();
}

function inRange(day, start, end) {
  if (!start || !end) return false;
  const t = day.getTime();
  return t > start.getTime() && t < end.getTime();
}

function isBefore(a, b) {
  return a.getTime() < b.getTime();
}

function getDaysInMonth(year, month) {
  return new Date(year, month + 1, 0).getDate();
}

function getFirstDayOfMonth(year, month) {
  return new Date(year, month, 1).getDay();
}

function getSlaColor(pct) {
  if (pct >= 90) return "bg-green-100 text-green-700";
  if (pct >= 75) return "bg-amber-100 text-amber-800";
  return "bg-red-100 text-red-700";
}

function getSlaStatusChip(status) {
  const map = {
    Met: "bg-green-100 text-green-700",
    "On Track": "bg-blue-100 text-blue-700",
    "At Risk": "bg-amber-100 text-amber-800",
    Breached: "bg-red-100 text-red-700",
  };
  return map[status] ?? "bg-gray-100 text-gray-600";
}

function getCaseStatusChip(status) {
  const map = {
    Completed: "bg-green-100 text-green-700",
    "In Progress": "bg-blue-100 text-blue-700",
    Pending: "bg-gray-100 text-gray-500",
  };
  return map[status] ?? "bg-gray-100 text-gray-600";
}

function StarRating({ value }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((s) => (
        <FiStar
          key={s}
          size={11}
          className={
            s <= Math.round(value)
              ? "text-amber-400 fill-amber-400"
              : "text-gray-200"
          }
          style={s <= Math.round(value) ? { fill: "currentColor" } : {}}
        />
      ))}
      <span className="ml-1 text-[11px] font-bold text-gray-600">
        {value.toFixed(1)}
      </span>
    </div>
  );
}

// Mini sparkline using SVG
function Sparkline({ data, color = "#6366f1" }) {
  if (!data || data.length === 0) {
    return (
      <svg width={80} height={30} className="overflow-visible">
        <text x={5} y={20} fontSize={10} fill="#999">
          No data
        </text>
      </svg>
    );
  }

  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const w = 80;
  const h = 30;
  const pts = data.map((v, i) => {
    const x = (i / (data.length - 1)) * w;
    const y = h - ((v - min) / range) * h;
    return `${x},${y}`;
  });
  return (
    <svg width={w} height={h} className="overflow-visible">
      <polyline
        points={pts.join(" ")}
        fill="none"
        stroke={color}
        strokeWidth="1.8"
        strokeLinejoin="round"
        strokeLinecap="round"
      />
      <circle
        cx={pts[pts.length - 1].split(",")[0]}
        cy={pts[pts.length - 1].split(",")[1]}
        r="2.5"
        fill={color}
      />
    </svg>
  );
}

// ─── DateRangePicker ──────────────────────────────────────────────────────────

function DateRangePicker({ startDate, endDate, onChange }) {
  const today = new Date();
  const [open, setOpen] = useState(false);
  const [hovered, setHovered] = useState(null);
  const [selecting, setSelecting] = useState(null);
  const [viewYear, setViewYear] = useState(today.getFullYear());
  const [viewMonth, setViewMonth] = useState(today.getMonth());
  const [rightYear, setRightYear] = useState(
    today.getMonth() === 11 ? today.getFullYear() + 1 : today.getFullYear(),
  );
  const [rightMonth, setRightMonth] = useState(
    today.getMonth() === 11 ? 0 : today.getMonth() + 1,
  );
  const ref = useRef(null);

  useEffect(() => {
    let ry = viewYear;
    let rm = viewMonth + 1;
    if (rm > 11) {
      rm = 0;
      ry += 1;
    }
    setRightYear(ry);
    setRightMonth(rm);
  }, [viewYear, viewMonth]);

  useEffect(() => {
    function handler(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  function prevMonth() {
    if (viewMonth === 0) {
      setViewMonth(11);
      setViewYear((y) => y - 1);
    } else setViewMonth((m) => m - 1);
  }

  function nextMonth() {
    if (viewMonth === 11) {
      setViewMonth(0);
      setViewYear((y) => y + 1);
    } else setViewMonth((m) => m + 1);
  }

  function handleDayClick(date) {
    if (!selecting) {
      setSelecting(date);
      onChange({ start: date, end: null });
    } else {
      const start = isBefore(selecting, date) ? selecting : date;
      const end = isBefore(selecting, date) ? date : selecting;
      onChange({ start, end });
      setSelecting(null);
      setOpen(false);
    }
  }

  const effectiveStart = selecting || startDate;
  const effectiveEnd = selecting
    ? hovered && !sameDay(hovered, selecting)
      ? isBefore(selecting, hovered)
        ? hovered
        : selecting
      : null
    : endDate;
  const effectiveStartFinal =
    selecting && hovered && isBefore(hovered, selecting)
      ? hovered
      : effectiveStart;

  function renderMonth(year, month) {
    const days = getDaysInMonth(year, month);
    const firstDay = getFirstDayOfMonth(year, month);
    const cells = [];

    for (let i = 0; i < firstDay; i++) cells.push(null);
    for (let d = 1; d <= days; d++) cells.push(new Date(year, month, d));

    return (
      <div className="w-full">
        <p className="text-center text-sm font-black text-gray-700 mb-3">
          {MONTH_NAMES[month]} {year}
        </p>
        <div className="grid grid-cols-7 mb-1">
          {DAY_NAMES.map((d) => (
            <div
              key={d}
              className="text-center text-[10px] font-bold text-gray-400 uppercase py-1"
            >
              {d}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-y-0.5">
          {cells.map((date, i) => {
            if (!date) return <div key={`e-${i}`} />;
            const isStart =
              sameDay(date, effectiveStart) ||
              sameDay(date, effectiveStartFinal);
            const isEnd = sameDay(date, effectiveEnd);
            const isInRange = inRange(
              date,
              effectiveStartFinal || effectiveStart,
              effectiveEnd,
            );
            const isToday = sameDay(date, today);

            let bg = "";
            let text = "text-gray-700 hover:bg-gray-100";
            let rounded = "rounded-lg";

            if (isStart || isEnd) {
              bg = "bg-secondary";
              text = "text-white";
              rounded =
                isStart && isEnd
                  ? "rounded-lg"
                  : isStart
                    ? "rounded-l-lg rounded-r-none"
                    : "rounded-r-lg rounded-l-none";
            } else if (isInRange) {
              bg = "bg-secondary/10";
              text = "text-secondary font-semibold";
              rounded = "rounded-none";
            }

            return (
              <button
                key={date.toISOString()}
                type="button"
                onClick={() => handleDayClick(date)}
                onMouseEnter={() => setHovered(date)}
                onMouseLeave={() => setHovered(null)}
                className={`relative text-center text-xs py-1.5 transition-all cursor-pointer w-full ${bg} ${text} ${rounded} ${isToday && !isStart && !isEnd ? "font-black underline" : ""}`}
              >
                {date.getDate()}
              </button>
            );
          })}
        </div>
      </div>
    );
  }

  const hasRange = startDate && endDate;

  return (
    <div className="relative" ref={ref}>
      <label className="text-xs font-bold text-gray-600 uppercase tracking-wide block mb-1">
        Date Range
      </label>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className={`inline-flex items-center gap-2 px-3 py-2 text-sm border rounded-xl bg-white transition-all w-full sm:w-auto sm:min-w-[260px] ${
          open
            ? "border-secondary/50 ring-2 ring-secondary/20 shadow-sm"
            : "border-gray-200 hover:border-gray-300"
        }`}
      >
        <FiCalendar size={14} className="text-gray-400 shrink-0" />
        {hasRange ? (
          <span className="font-semibold text-gray-700 flex-1 text-left">
            {formatDate(startDate)} → {formatDate(endDate)}
          </span>
        ) : (
          <span className="text-gray-400 flex-1 text-left">
            Select your date
          </span>
        )}
        {hasRange && (
          <span
            role="button"
            tabIndex={0}
            onClick={(e) => {
              e.stopPropagation();
              onChange({ start: null, end: null });
              setSelecting(null);
            }}
            onKeyDown={(e) =>
              e.key === "Enter" && onChange({ start: null, end: null })
            }
            className="ml-auto text-gray-300 hover:text-gray-500 transition-colors"
          >
            <FiX size={13} />
          </span>
        )}
      </button>

      {open && (
        <div className="absolute left-0 top-full mt-2 z-50 bg-white border border-gray-200 rounded-2xl shadow-xl p-4 min-w-[340px] sm:min-w-[600px]">
          <div className="mb-3 flex items-center justify-between">
            <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">
              {selecting ? "Now pick an end date" : "Pick a start date"}
            </span>
            {selecting && (
              <button
                type="button"
                onClick={() => {
                  setSelecting(null);
                  onChange({ start: null, end: null });
                }}
                className="text-[11px] text-gray-400 hover:text-gray-600 underline"
              >
                Reset
              </button>
            )}
          </div>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="flex items-center justify-between mb-2">
                <button
                  type="button"
                  onClick={prevMonth}
                  className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-500"
                >
                  <FiChevronLeft size={15} />
                </button>
                <span />
                <button
                  type="button"
                  onClick={nextMonth}
                  className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-500 sm:invisible"
                >
                  <FiChevronRight size={15} />
                </button>
              </div>
              {renderMonth(viewYear, viewMonth)}
            </div>
            <div className="hidden sm:block w-px bg-gray-100 self-stretch" />
            <div className="flex-1 hidden sm:block">
              <div className="flex items-center justify-between mb-2">
                <span />
                <button
                  type="button"
                  onClick={nextMonth}
                  className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-500"
                >
                  <FiChevronRight size={15} />
                </button>
              </div>
              {renderMonth(rightYear, rightMonth)}
            </div>
          </div>
          <div className="mt-4 pt-3 border-t border-gray-100 flex flex-wrap gap-2">
            {[
              {
                label: "This month",
                fn: () => {
                  const n = new Date();
                  onChange({
                    start: new Date(n.getFullYear(), n.getMonth(), 1),
                    end: new Date(n.getFullYear(), n.getMonth() + 1, 0),
                  });
                  setSelecting(null);
                  setOpen(false);
                },
              },
              {
                label: "Last 30 days",
                fn: () => {
                  const e = new Date();
                  const s = new Date();
                  s.setDate(s.getDate() - 29);
                  onChange({ start: s, end: e });
                  setSelecting(null);
                  setOpen(false);
                },
              },
              {
                label: "Last 90 days",
                fn: () => {
                  const e = new Date();
                  const s = new Date();
                  s.setDate(s.getDate() - 89);
                  onChange({ start: s, end: e });
                  setSelecting(null);
                  setOpen(false);
                },
              },
              {
                label: "This year",
                fn: () => {
                  const n = new Date();
                  onChange({
                    start: new Date(n.getFullYear(), 0, 1),
                    end: new Date(n.getFullYear(), 11, 31),
                  });
                  setSelecting(null);
                  setOpen(false);
                },
              },
            ].map((p) => (
              <button
                key={p.label}
                type="button"
                onClick={p.fn}
                className="px-3 py-1 text-xs font-semibold text-gray-600 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded-lg transition-colors"
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── DateRangeBadge ───────────────────────────────────────────────────────────

function DateRangeBadge({ startDate, endDate }) {
  if (!startDate && !endDate) return null;
  const label =
    startDate && endDate
      ? `${formatDate(startDate)} → ${formatDate(endDate)}`
      : startDate
        ? `From ${formatDate(startDate)}`
        : `Until ${formatDate(endDate)}`;
  let days = null;
  if (startDate && endDate) {
    const diff = endDate.getTime() - startDate.getTime();
    days = Math.round(diff / (1000 * 60 * 60 * 24)) + 1;
  }
  return (
    <div
      key="badge"
      className="inline-flex items-center gap-2 px-4 py-2.5 bg-secondary/5 border border-secondary/20 rounded-xl text-sm font-bold text-secondary shadow-sm"
    >
      <FiCalendar size={13} className="shrink-0 opacity-70" />
      <span>{label}</span>
      {days !== null && (
        <span className="ml-1 px-1.5 py-0.5 rounded-md bg-secondary/15 text-[10px] font-black text-secondary">
          {days}d
        </span>
      )}
    </div>
  );
}

// ─── Performance Detail Modal ─────────────────────────────────────────────────

function PerformanceDetailModal({ caseworker, onClose, showToast }) {
  if (!caseworker) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center bg-black/40 backdrop-blur-sm overflow-y-auto py-8 px-4"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl border border-gray-100">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-5 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div
              className={`w-10 h-10 rounded-xl flex items-center justify-center text-sm font-black text-white shrink-0 ${caseworker.avatarBg || "bg-blue-500"}`}
            >
              {caseworker.initials || "N/A"}
            </div>
            <div>
              <h2 className="text-base font-black text-secondary">
                {caseworker.name || "N/A"}
              </h2>
              <p className="text-xs text-gray-400">
                {caseworker.id || "N/A"} · {caseworker.department || "General"}{" "}
                · Joined{" "}
                {caseworker.joinDate || new Date().toLocaleDateString("en-GB")}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors"
          >
            <FiX size={18} />
          </button>
        </div>

        <div className="p-5 space-y-5">
          {/* KPI Row */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              {
                label: "Total Cases",
                value: caseworker.totalCases || 0,
                icon: <FiFileText size={14} />,
                color: "text-blue-600",
                bg: "bg-blue-50",
              },
              {
                label: "SLA Met",
                value: `${caseworker.slaMetPct || 0}%`,
                icon: <FiCheckCircle size={14} />,
                color: "text-green-600",
                bg: "bg-green-50",
              },
              {
                label: "Avg Days",
                value: `${caseworker.avgCompletionDays || 0}d`,
                icon: <FiClock size={14} />,
                color: "text-amber-700",
                bg: "bg-amber-50",
              },
              {
                label: "Escalations",
                value: caseworker.escalations || 0,
                icon: <FiAlertCircle size={14} />,
                color: "text-red-600",
                bg: "bg-red-50",
              },
            ].map((k) => (
              <div
                key={k.label}
                className={`rounded-xl p-3.5 ${k.bg} border border-white`}
              >
                <div className={`flex items-center gap-1.5 mb-1 ${k.color}`}>
                  {k.icon}
                  <span className="text-[10px] font-black uppercase tracking-wide">
                    {k.label}
                  </span>
                </div>
                <p className={`text-2xl font-black ${k.color}`}>{k.value}</p>
              </div>
            ))}
          </div>

          {/* Satisfaction + Trend */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-gray-50 rounded-xl p-4 border border-gray-100">
              <p className="text-[10px] font-black text-gray-400 uppercase tracking-wider mb-2">
                Client Satisfaction
              </p>
              <StarRating value={caseworker.clientSatisfaction || 3} />
              <p className="text-xs text-gray-400 mt-1.5">
                {caseworker.completedCases || 0} completed cases reviewed
              </p>
            </div>
            <div className="bg-gray-50 rounded-xl p-4 border border-gray-100">
              <p className="text-[10px] font-black text-gray-400 uppercase tracking-wider mb-2">
                12-Month Case Trend
              </p>
              <Sparkline
                data={caseworker.monthlyTrend || Array(12).fill(0)}
                color="#6366f1"
              />
              {caseworker.monthlyTrend && caseworker.monthlyTrend.length > 0 ? (
                <p className="text-xs text-gray-400 mt-1">
                  {caseworker.monthlyTrend[caseworker.monthlyTrend.length - 1] >
                  caseworker.monthlyTrend[0] ? (
                    <span className="text-green-600 font-bold">
                      ↑ Improving
                    </span>
                  ) : (
                    <span className="text-red-500 font-bold">↓ Declining</span>
                  )}
                </p>
              ) : (
                <p className="text-xs text-gray-400 mt-1">No trend data</p>
              )}
            </div>
          </div>

          {/* Visa Breakdown */}
          <div>
            <p className="text-[10px] font-black text-gray-400 uppercase tracking-wider mb-2">
              Cases by Visa Type
            </p>
            {caseworker.visaBreakdown && caseworker.visaBreakdown.length > 0 ? (
              <div className="space-y-2">
                {caseworker.visaBreakdown.map((v) => {
                  const pct =
                    caseworker.totalCases > 0
                      ? Math.round((v.count / caseworker.totalCases) * 100)
                      : 0;
                  return (
                    <div key={v.type}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="font-semibold text-gray-700">
                          {v.type}
                        </span>
                        <span className="text-gray-500 font-mono">
                          {v.count} ({pct}%)
                        </span>
                      </div>
                      <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full bg-secondary"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-xs text-gray-400">
                No visa type data available
              </p>
            )}
          </div>

          {/* Recent Cases */}
          <div>
            <p className="text-[10px] font-black text-gray-400 uppercase tracking-wider mb-2">
              Recent Cases
            </p>
            {caseworker.recentCases && caseworker.recentCases.length > 0 ? (
              <div className="rounded-xl border border-gray-100 overflow-hidden">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="bg-gray-50 text-left">
                      {[
                        "Case ID",
                        "Client",
                        "Visa Type",
                        "Status",
                        "Date",
                        "SLA",
                      ].map((h) => (
                        <th
                          key={h}
                          className="px-3 py-2.5 text-[10px] font-black text-gray-400 uppercase tracking-wider whitespace-nowrap"
                        >
                          {h}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {caseworker.recentCases.map((c) => (
                      <tr
                        key={c.id}
                        className="hover:bg-gray-50/60 transition-colors"
                      >
                        <td className="px-3 py-2.5 font-mono text-secondary font-bold">
                          {c.id || c.caseId || "N/A"}
                        </td>
                        <td className="px-3 py-2.5 font-medium text-gray-700 whitespace-nowrap">
                          {c.client || "N/A"}
                        </td>
                        <td className="px-3 py-2.5 text-gray-500 whitespace-nowrap">
                          {c.type || "N/A"}
                        </td>
                        <td className="px-3 py-2.5">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-black ${getCaseStatusChip(c.status)}`}
                          >
                            {c.status || "N/A"}
                          </span>
                        </td>
                        <td className="px-3 py-2.5 text-gray-500 whitespace-nowrap">
                          {c.date || "N/A"}
                        </td>
                        <td className="px-3 py-2.5">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-black ${getSlaStatusChip(c.sla)}`}
                          >
                            {c.sla || "N/A"}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-6 text-gray-400">
                <p className="text-sm">No recent cases available</p>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 p-5 border-t border-gray-100 bg-gray-50/60 rounded-b-2xl">
          <Button
            type="button"
            variant="outline"
            className="rounded-xl"
            onClick={onClose}
          >
            Close
          </Button>
        </div>
      </div>
    </div>
  );
}

// ─── Performance Tab ──────────────────────────────────────────────────────────

function PerformanceTab({
  dateRange,
  performanceData,
  deptOptions,
  showToast,
  refreshTrigger,
}) {
  const [search, setSearch] = useState("");
  const [deptFilter, setDeptFilter] = useState("all");
  const [slaFilter, setSlaFilter] = useState("all");
  const [selectedCW, setSelectedCW] = useState(null);
  const [caseworkers, setCaseworkers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [searchTimeout, setSearchTimeout] = useState(null);

  const DEPT_OPTIONS = [{ value: "all", label: "All departments" }];

  const SLA_OPTIONS = [
    { value: "all", label: "All SLA levels" },
    { value: "high", label: "High (≥90%)" },
    { value: "mid", label: "Medium (75–89%)" },
    { value: "low", label: "Low (<75%)" },
  ];

  // API-based fetch using standard reporting wrapper
  const fetchFilteredCaseworkers = useCallback(
    async (searchTerm = "", dept = "all", sla = "all") => {
      setLoading(true);
      setError(null);
      try {
        const params = {};
        if (dateRange?.start) {
          params.startDate = dateRange.start.toISOString().split("T")[0];
        }
        if (dateRange?.end) {
          params.endDate = dateRange.end.toISOString().split("T")[0];
        }

        const response = await getPerformanceReport(params);
        let rawList = response.data?.data || [];

        // Client-side filtering to mimic local search/sla filtering
        if (searchTerm.trim()) {
          const q = searchTerm.trim().toLowerCase();
          rawList = rawList.filter(
            (cw) =>
              (cw.name || "").toLowerCase().includes(q) ||
              (cw.id || "").toLowerCase().includes(q) ||
              (cw.email || "").toLowerCase().includes(q),
          );
        }

        if (sla !== "all") {
          rawList = rawList.filter((cw) => {
            const pct = cw.slaMetPct || 0;
            if (sla === "high") return pct >= 90;
            if (sla === "mid") return pct >= 75 && pct < 90;
            if (sla === "low") return pct < 75;
            return true;
          });
        }

        // Normalize data to fit component UI expectations perfectly
        const normalizedData = rawList.map((cw) => {
          const pct = cw.slaMetPct || 0;
          return {
            ...cw,
            id: cw.id,
            caseworker_id: cw.id,
            name: cw.name || "N/A",
            email: cw.email || "N/A",
            department: cw.department || "Immigration",
            active_cases: cw.activeCases || 0,
            completed_cases: cw.completedCases || 0,
            workload_percentage: pct,
            health_status:
              pct >= 80 ? "healthy" : pct >= 60 ? "moderate" : "stressed",
            initials: cw.initials || "CW",
            avatarBg: cw.avatarBg || "bg-blue-500",
          };
        });

        setCaseworkers(normalizedData);
      } catch (err) {
        console.error("Error fetching caseworkers performance report:", err);
        setError("Failed to load caseworker performance data");
      } finally {
        setLoading(false);
      }
    },
    [dateRange],
  );

  // Fetch on component mount or global refresh trigger
  useEffect(() => {
    fetchFilteredCaseworkers();
  }, [fetchFilteredCaseworkers, refreshTrigger]);

  // Handle search input with debouncing
  const handleSearchChange = useCallback(
    (value) => {
      setSearch(value);

      if (searchTimeout) {
        clearTimeout(searchTimeout);
      }

      const timeout = setTimeout(() => {
        fetchFilteredCaseworkers(value, deptFilter, slaFilter);
      }, 300);

      setSearchTimeout(timeout);
    },
    [deptFilter, slaFilter, fetchFilteredCaseworkers, searchTimeout],
  );

  // Handle department filter change
  const handleDeptFilterChange = useCallback(
    (newDept) => {
      setDeptFilter(newDept);
      fetchFilteredCaseworkers(search, newDept, slaFilter);
    },
    [search, slaFilter, fetchFilteredCaseworkers],
  );

  // Handle SLA filter change
  const handleSlaFilterChange = useCallback(
    (newSla) => {
      setSlaFilter(newSla);
      fetchFilteredCaseworkers(search, deptFilter, newSla);
    },
    [search, deptFilter, fetchFilteredCaseworkers],
  );

  // Cleanup timeout on unmount
  useEffect(() => {
    return () => {
      if (searchTimeout) {
        clearTimeout(searchTimeout);
      }
    };
  }, [searchTimeout]);

  // Summary KPIs
  const data = caseworkers || [];
  const avgSla =
    data.length > 0
      ? (
          data.reduce((s, c) => s + (c.workload_percentage || 0), 0) /
          data.length
        ).toFixed(1)
      : 0;

  const totalCases = data.reduce(
    (s, c) => s + (c.active_cases || 0) + (c.completed_cases || 0),
    0,
  );

  const topPerformer =
    data.length > 0
      ? data.reduce((max, c) =>
          (c.workload_percentage || 0) > (max.workload_percentage || 0)
            ? c
            : max,
        )
      : null;

  // Handle download report triggers general export workbook
  const handleDownloadReport = async (caseworkerId) => {
    showToast?.({
      message: "Generating combined performance workbook export...",
      variant: "info",
    });
    try {
      const params = {};
      if (dateRange?.start)
        params.startDate = dateRange.start.toISOString().split("T")[0];
      if (dateRange?.end)
        params.endDate = dateRange.end.toISOString().split("T")[0];

      const res = await exportReportingExcel(params);
      const filename = `performance_metrics_${caseworkerId}_${new Date().toISOString().split("T")[0]}.xlsx`;
      const url = window.URL.createObjectURL(res.data);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (e) {
      console.error("Performance report download failed:", e);
      showToast?.({
        message: "Failed to export metrics workbook.",
        variant: "danger",
      });
    }
  };

  // Handle view performance details
  const handleViewPerformance = (caseworkerId) => {
    if (!caseworkerId) return;
    const target = caseworkers.find(
      (c) => c.id === caseworkerId || c.caseworker_id === caseworkerId,
    );
    if (target) {
      setSelectedCW(target);
    } else {
      showToast?.({
        message: "Performance details not found in current view.",
        variant: "warning",
      });
    }
  };

  return (
    <>
      {selectedCW && (
        <PerformanceDetailModal
          caseworker={selectedCW}
          onClose={() => setSelectedCW(null)}
          showToast={showToast}
        />
      )}

      <div key="performance" className="space-y-5">
        {/* Summary KPIs */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {/* Total Cases Card */}
          <div className="rounded-xl border border-blue-100 p-4 bg-blue-50">
            <p className="text-[11px] font-bold text-gray-400 uppercase tracking-wide mb-3">
              Total Cases (All Staff)
            </p>
            <p className="text-4xl font-black text-blue-600">{totalCases}</p>
            <p className="text-xs text-gray-500 mt-1">across all caseworkers</p>
          </div>

          {/* Avg Performance Card */}
          <div className="rounded-xl border border-green-100 p-4 bg-green-50">
            <p className="text-[11px] font-bold text-gray-400 uppercase tracking-wide mb-3">
              Avg Performance
            </p>
            <p className="text-4xl font-black text-green-600">{avgSla}%</p>
            <p className="text-xs text-gray-500 mt-1">
              team average this period
            </p>
          </div>

          {/* Top Performer Card */}
          <div className="rounded-xl border border-amber-100 p-4 bg-amber-50">
            <p className="text-[11px] font-bold text-gray-400 uppercase tracking-wide mb-3">
              Top Performer
            </p>
            {topPerformer ? (
              <div>
                <p className="text-lg font-black text-amber-700">
                  {topPerformer.name || "N/A"}
                </p>
                <p className="text-xs text-gray-500 mt-2">
                  {(topPerformer.workload_percentage || 0).toFixed(1)}% ·{" "}
                  {topPerformer.active_cases || 0} active
                </p>
              </div>
            ) : (
              <p className="text-sm text-gray-500">No data available</p>
            )}
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-4 sm:p-5">
          <div className="flex items-center gap-2 mb-3">
            <FiFilter size={13} className="text-gray-400" />
            <p className="text-[10px] font-black text-gray-400 uppercase tracking-wider">
              Filter Caseworkers
            </p>
          </div>
          <div className="flex flex-col sm:flex-row flex-wrap gap-3 sm:items-end">
            {/* Search */}
            <div className="flex-1 min-w-[220px] max-w-sm">
              <label className="text-xs font-bold text-gray-600 uppercase tracking-wide block mb-1">
                Search by name or ID
              </label>
              <div className="relative">
                <FiSearch
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
                  size={15}
                />
                <input
                  type="search"
                  value={search}
                  onChange={(e) => handleSearchChange(e.target.value)}
                  placeholder="e.g. Alice or CW-001"
                  className="w-full border border-gray-200 rounded-xl pl-10 pr-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-secondary/30"
                />
              </div>
            </div>
            {/* SLA filter */}
            <div className="w-full sm:w-auto sm:min-w-[200px]">
              <Input
                label="SLA level"
                name="slaFilter"
                value={slaFilter}
                onChange={(e) => handleSlaFilterChange(e.target.value)}
                options={SLA_OPTIONS}
              />
            </div>

            {/* Reset */}
            {(search || slaFilter !== "all") && (
              <button
                type="button"
                onClick={() => {
                  handleSearchChange("");
                  handleSlaFilterChange("all");
                }}
                className="self-end px-3 py-2 text-xs font-bold text-gray-500 hover:text-gray-700 border border-gray-200 rounded-xl bg-white hover:bg-gray-50 transition-colors inline-flex items-center gap-1.5"
              >
                <FiX size={12} /> Reset filters
              </button>
            )}
          </div>
        </div>

        {/* Table */}
        <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-gray-100 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
            <div>
              <h2 className="text-sm font-black text-secondary">
                Caseworker Performance Report
              </h2>
              <p className="text-xs text-gray-500 mt-0.5">
                Showing {caseworkers.length} caseworker
                {caseworkers.length !== 1 ? "s" : ""}
              </p>
            </div>
          </div>

          {loading ? (
            <div className="px-5 py-12 text-center">
              <FiLoader
                className="animate-spin inline-block text-secondary mb-2"
                size={24}
              />
              <p className="text-sm text-gray-500">
                Loading caseworker data...
              </p>
            </div>
          ) : error ? (
            <div className="px-5 py-12 text-center">
              <FiAlertCircle
                className="inline-block text-red-500 mb-2"
                size={24}
              />
              <p className="text-sm text-red-500">{error}</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[800px]">
                <thead>
                  <tr className="bg-gray-50 text-left">
                    {[
                      "Caseworker",
                      "Email",
                      "Department",
                      "Active",
                      "Completed",
                      "Workload %",
                      "Status",
                      "Actions",
                    ].map((h) => (
                      <th
                        key={h}
                        className="px-4 py-3 text-[10px] font-black text-gray-400 uppercase tracking-wider whitespace-nowrap"
                      >
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {caseworkers.length === 0 ? (
                    <tr>
                      <td
                        colSpan={8}
                        className="px-4 py-12 text-center text-sm text-gray-400"
                      >
                        <div className="flex flex-col items-center gap-2">
                          <FiUser size={28} className="text-gray-200" />
                          <span>No caseworkers match your filters.</span>
                        </div>
                      </td>
                    </tr>
                  ) : (
                    caseworkers.map((cw) => (
                      <tr
                        key={cw.id}
                        className="hover:bg-gray-50/80 transition-colors group"
                      >
                        {/* Caseworker */}
                        <td className="px-4 py-3.5">
                          <div className="flex items-center gap-2.5">
                            <p
                              className={`text-xs font-bold text-white ${cw.avatarBg || "bg-blue-500"} rounded-full w-8 h-8 flex items-center justify-center shrink-0`}
                            >
                              {cw.initials || "N/A"}
                            </p>
                            <p className="text-sm font-bold text-secondary whitespace-nowrap">
                              {cw.name || "N/A"}
                            </p>
                          </div>
                        </td>

                        {/* Email */}
                        <td className="px-4 py-3.5">
                          <p className="text-[10px] text-gray-400 whitespace-nowrap">
                            {cw.email || "N/A"}
                          </p>
                        </td>
                        {/* Dept */}
                        <td className="px-4 py-3.5"></td>
                        {/* Active */}
                        <td className="px-4 py-3.5 text-sm font-semibold text-gray-800 tabular-nums">
                          {cw.active_cases || 0}
                        </td>
                        {/* Completed */}
                        <td className="px-4 py-3.5 text-sm font-semibold text-gray-800 tabular-nums">
                          {cw.completed_cases || 0}
                        </td>
                        {/* Workload % */}
                        <td className="px-4 py-3.5">
                          <span
                            className={`px-2.5 py-1 rounded-full text-[10px] font-black ${getSlaColor(cw.workload_percentage || 0)}`}
                          >
                            {(cw.workload_percentage || 0).toFixed(1)}%
                          </span>
                        </td>
                        {/* Status */}
                        <td className="px-4 py-3.5">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-black ${cw.health_status === "healthy" ? "bg-green-100 text-green-700" : cw.health_status === "moderate" ? "bg-amber-100 text-amber-800" : "bg-red-100 text-red-700"}`}
                          >
                            {cw.health_status || "Unknown"}
                          </span>
                        </td>
                        {/* Actions */}
                        <td className="px-4 py-3.5">
                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() =>
                                handleViewPerformance(cw.id || cw.caseworker_id)
                              }
                              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl border border-secondary/30 text-secondary bg-secondary/5 hover:bg-secondary/10 transition-colors whitespace-nowrap"
                            >
                              <FiEye size={12} />
                              View
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                handleDownloadReport(cw.id || cw.caseworker_id)
                              }
                              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl border border-primary/30 text-primary bg-primary/5 hover:bg-primary/10 transition-colors whitespace-nowrap"
                            >
                              <FiDownload size={12} />
                              Report
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}
          {/* Table footer */}
          {caseworkers.length > 0 && (
            <div className="px-5 py-3 border-t border-gray-100 bg-gray-50/50 flex flex-wrap items-center justify-between gap-2 text-xs text-gray-400">
              <span>
                {caseworkers.length} result{caseworkers.length !== 1 ? "s" : ""}
              </span>
              <span className="font-mono">
                Team avg workload:{" "}
                <span className="font-black text-secondary">{avgSla}%</span>
              </span>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

export default function AdminReports() {
  const { showToast } = useToast();
  const [activeTab, setActiveTab] = useState("cases");
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [reportExporting, setReportExporting] = useState(false);
  const [performanceData, setPerformanceData] = useState(null);
  const [deptOptions, setDeptOptions] = useState([]);
  const [dateRange, setDateRange] = useState({ start: null, end: null });
  const [visaFilter, setVisaFilter] = useState("all");

  // Case Type Data
  const [caseTypes, setCaseTypes] = useState([]);
  const [caseTypesLoading, setCaseTypesLoading] = useState(false);
  const [caseTypesError, setCaseTypesError] = useState(null);

  // Workload Data
  const [workload, setWorkload] = useState([]);
  const [workloadLoading, setWorkloadLoading] = useState(false);
  const [workloadError, setWorkloadError] = useState(null);
  const [workloadSearch, setWorkloadSearch] = useState("");

  // Financial Data
  const [revenueByVisa, setRevenueByVisa] = useState([]);
  const [revenueBySponsor, setRevenueBySponsor] = useState([]);
  const [financeLoading, setFinanceLoading] = useState(false);
  const [financeError, setFinanceError] = useState(null);
  const [financeSearch, setFinanceSearch] = useState("");
  const [usingMockData, setUsingMockData] = useState(false);
  const apiLoading = caseTypesLoading || workloadLoading || financeLoading;

  // Tab visibility tracking for lazy loading
  const [loadedTabs, setLoadedTabs] = useState(new Set(["cases"])); // Default to cases tab

  // ─── API Fetch Functions ──────────────────────────────────────

  const buildParams = useCallback(() => {
    const params = {};
    if (dateRange?.start) {
      params.startDate = dateRange.start.toISOString().split("T")[0];
    }
    if (dateRange?.end) {
      params.endDate = dateRange.end.toISOString().split("T")[0];
    }
    return params;
  }, [dateRange]);

  // Fetch case type report
  const fetchCaseTypeReport = useCallback(async () => {
    setCaseTypesLoading(true);
    setCaseTypesError(null);
    try {
      const response = await getCaseAnalytics(buildParams());
      if (response.data?.data?.byVisaType) {
        setCaseTypes(
          response.data.data.byVisaType.map((v) => ({
            type: v.name,
            count: v.count,
          })),
        );
      } else {
        setCaseTypes([]);
      }
    } catch (err) {
      console.error("Error fetching case type report:", err);
      setCaseTypes(MOCK_REPORT_CASE_TYPES);
      setCaseTypesError(null);
      setUsingMockData(true);
    } finally {
      setCaseTypesLoading(false);
    }
  }, [buildParams]);

  // Fetch workload report
  const fetchWorkloadReport = useCallback(async () => {
    setWorkloadLoading(true);
    setWorkloadError(null);
    try {
      const response = await getWorkloadReport(buildParams());
      if (response.data?.data?.caseworkers) {
        const mapped = response.data.data.caseworkers.map((c) => ({
          caseworker_id: c.id,
          caseworker_name: c.name,
          email: c.email,
          active_cases: c.activeCases || 0,
          overdue: Math.max(
            0,
            (c.totalCases || 0) -
              (c.completedCases || 0) -
              (c.activeCases || 0),
          ),
          tasks_pending: 0,
          workload_percentage: c.slaMetPct || 0,
          health_status:
            (c.slaMetPct || 0) >= 80
              ? "healthy"
              : (c.slaMetPct || 0) >= 60
                ? "moderate"
                : "stressed",
          health_color:
            (c.slaMetPct || 0) >= 80
              ? "green"
              : (c.slaMetPct || 0) >= 60
                ? "amber"
                : "red",
        }));
        setWorkload(mapped);
      } else {
        setWorkload([]);
      }
    } catch (err) {
      console.error("Error fetching workload report:", err);
      setWorkload(MOCK_REPORT_WORKLOAD);
      setWorkloadError(null);
      setUsingMockData(true);
    } finally {
      setWorkloadLoading(false);
    }
  }, [buildParams]);

  // Fetch financial reports
  const fetchFinancialReports = useCallback(async () => {
    setFinanceLoading(true);
    setFinanceError(null);
    try {
      const response = await getFinancialReport(buildParams());
      if (response.data?.data) {
        const { byVisaType, bySponsor } = response.data.data;
        setRevenueByVisa(
          (byVisaType || []).map((v) => ({
            visa_type: v.name,
            total_amount: v.total,
          })),
        );
        setRevenueBySponsor(
          (bySponsor || []).map((s) => ({
            sponsor_name: s.name,
            total_amount: s.total,
          })),
        );
      }
    } catch (err) {
      console.error("Error fetching financial reports:", err);
      setRevenueByVisa(
        MOCK_REPORT_FINANCE.byVisaType.map((v) => ({
          visa_type: v.name,
          total_amount: v.total,
        })),
      );
      setRevenueBySponsor(
        MOCK_REPORT_FINANCE.bySponsor.map((s) => ({
          sponsor_name: s.name,
          total_amount: s.total,
        })),
      );
      setFinanceError(null);
      setUsingMockData(true);
    } finally {
      setFinanceLoading(false);
    }
  }, [buildParams]);

  // Trigger data updates when tab changes or dateRange filters update
  const refreshActiveView = useCallback(() => {
    if (activeTab === "cases") fetchCaseTypeReport();
    if (activeTab === "workload") fetchWorkloadReport();
    if (activeTab === "finance") fetchFinancialReports();
  }, [
    activeTab,
    fetchCaseTypeReport,
    fetchWorkloadReport,
    fetchFinancialReports,
  ]);

  // Handle tab change - lazy load data when tab is clicked
  const handleTabChange = (tabId) => {
    setActiveTab(tabId);

    if (!loadedTabs.has(tabId)) {
      const newLoadedTabs = new Set(loadedTabs);
      newLoadedTabs.add(tabId);
      setLoadedTabs(newLoadedTabs);
    }
  };

  // Keep view synchronized when switching tabs or date filters change
  useEffect(() => {
    refreshActiveView();
  }, [refreshActiveView]);

  const handleExportWorkbook = async () => {
    setReportExporting(true);
    try {
      const res = await exportReportingExcel({});
      const filename = `reports_${new Date().toISOString().split("T")[0]}.xlsx`;
      const url = window.URL.createObjectURL(res.data);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      showToast({
        message: "Report workbook downloaded successfully.",
        variant: "success",
      });
    } catch (e) {
      console.error("Report export failed:", e);
      showToast({
        message: "Failed to export report workbook.",
        variant: "danger",
      });
    } finally {
      setReportExporting(false);
    }
  };

  function handleDateRangeChange({ start, end }) {
    setDateRange({ start, end });
  }

  // Filter workload data
  const filteredWorkload = useMemo(() => {
    const q = workloadSearch.trim().toLowerCase();
    if (!q) return workload;
    return workload.filter((r) =>
      (r.caseworker_name || "").toLowerCase().includes(q),
    );
  }, [workloadSearch, workload]);

  // Filter finance data
  const filteredFinanceVisa = useMemo(() => {
    const q = financeSearch.trim().toLowerCase();
    if (!q) return revenueByVisa;
    return revenueByVisa.filter((r) =>
      (r.visa_type || "").toLowerCase().includes(q),
    );
  }, [financeSearch, revenueByVisa]);

  const filteredFinanceSponsor = useMemo(() => {
    const q = financeSearch.trim().toLowerCase();
    if (!q) return revenueBySponsor;
    return revenueBySponsor.filter((r) =>
      (r.sponsor_name || "").toLowerCase().includes(q),
    );
  }, [financeSearch, revenueBySponsor]);

  return (
    <div className="relative space-y-6 pb-10">
      {/* Loading overlay */}
      {apiLoading && (
        <div className="absolute inset-0 z-30 bg-white/60 backdrop-blur-[1px] flex items-start justify-center pt-24 rounded-xl">
          <div className="flex items-center gap-2 text-sm font-semibold text-gray-500 bg-white px-4 py-2.5 rounded-xl shadow-md border border-gray-100">
            <FiRefreshCw className="animate-spin" size={14} />
            Refreshing data…
          </div>
        </div>
      )}

      {usingMockData && <MockDataBanner />}

      {/* ── Header ── */}
      <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="mt-1 p-2.5 rounded-2xl bg-white border border-gray-100 shadow-sm shrink-0">
            <RiBarChartLine className="text-primary" size={22} />
          </div>
          <div>
            <h1 className="text-3xl font-black text-secondary tracking-tight">
              Reporting &amp; Analytics
            </h1>
            <p className="text-sm text-gray-500 mt-0.5">
              Performance metrics and business intelligence
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <DateRangeBadge startDate={dateRange.start} endDate={dateRange.end} />
          <button
            type="button"
            disabled={apiLoading}
            onClick={() => {
              refreshActiveView();
              setRefreshTrigger((t) => t + 1);
            }}
            className="p-2 rounded-xl border border-gray-200 bg-white text-gray-400 hover:text-primary hover:border-primary/30 transition-colors"
            title="Refresh data"
          >
            <FiRefreshCw
              size={15}
              className={apiLoading ? "animate-spin" : ""}
            />
          </button>
          <Button
            type="button"
            variant="primary"
            className="rounded-xl shadow-sm inline-flex items-center gap-2"
            onClick={handleExportWorkbook}
            disabled={apiLoading || reportExporting}
          >
            {reportExporting ? (
              <Loader2 size={14} className="animate-spin" />
            ) : (
              <FiDownload size={14} />
            )}
            Export Excel
          </Button>
        </div>
      </div>

      {/* ── Filters ── */}
      <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-4 sm:p-5">
        <p className="text-[10px] font-black text-gray-400 uppercase tracking-wider mb-3">
          Filters
        </p>
        <div className="flex flex-col lg:flex-row flex-wrap gap-4 lg:items-end">
          <DateRangePicker
            startDate={dateRange.start}
            endDate={dateRange.end}
            onChange={handleDateRangeChange}
          />

          {activeTab === "workload" && (
            <div className="w-full sm:flex-1 sm:min-w-[240px] max-w-md">
              <label
                htmlFor="workload-search"
                className="text-xs font-bold text-gray-600 uppercase tracking-wide block mb-1"
              >
                Search caseworker
              </label>
              <div className="relative">
                <FiSearch
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
                  size={16}
                />
                <input
                  id="workload-search"
                  type="search"
                  value={workloadSearch}
                  onChange={(e) => setWorkloadSearch(e.target.value)}
                  placeholder="Filter by name…"
                  className="w-full border border-gray-200 rounded-xl pl-10 pr-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-secondary/30"
                />
              </div>
            </div>
          )}

          {activeTab === "finance" && (
            <div className="w-full sm:flex-1 sm:min-w-[240px] max-w-md">
              <label
                htmlFor="finance-search"
                className="text-xs font-bold text-gray-600 uppercase tracking-wide block mb-1"
              >
                Search revenue lines
              </label>
              <div className="relative">
                <FiSearch
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
                  size={16}
                />
                <input
                  id="finance-search"
                  type="search"
                  value={financeSearch}
                  onChange={(e) => setFinanceSearch(e.target.value)}
                  placeholder="Filter visa type or sponsor…"
                  className="w-full border border-gray-200 rounded-xl pl-10 pr-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-secondary/30"
                />
              </div>
            </div>
          )}
        </div>
      </div>

      <SegmentedTabBar
        tabs={TABS}
        activeId={activeTab}
        onChange={handleTabChange}
      />

      {/* ── Cases Tab ── */}
      {activeTab === "cases" && (
        <div key="cases" className="space-y-6">
          {caseTypesLoading ? (
            <div className="text-center py-12">
              <FiLoader
                className="animate-spin inline-block text-secondary mb-2"
                size={28}
              />
              <p className="text-sm text-gray-500">Loading case reports...</p>
            </div>
          ) : caseTypesError ? (
            <div className="text-center py-12">
              <FiAlertCircle
                className="inline-block text-red-500 mb-2"
                size={28}
              />
              <p className="text-sm text-red-500">{caseTypesError}</p>
            </div>
          ) : (
            <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5 sm:p-6">
              <h2 className="text-sm font-black text-secondary pb-3 mb-4 border-b border-gray-100">
                Cases by Type
              </h2>
              {caseTypes.length === 0 ? (
                <p className="text-sm text-gray-400 text-center py-8">
                  No case type data available.
                </p>
              ) : (
                <div className="space-y-4">
                  {caseTypes.map((row, idx) => {
                    const total = caseTypes.reduce(
                      (sum, c) => sum + (c.count || 0),
                      0,
                    );
                    const pct =
                      total > 0 ? Math.round((row.count / total) * 100) : 0;
                    const colors = [
                      "bg-blue-500",
                      "bg-purple-500",
                      "bg-green-500",
                      "bg-amber-400",
                      "bg-red-500",
                    ];

                    return (
                      <div key={row.type || idx}>
                        <div className="flex justify-between text-xs sm:text-sm mb-1.5">
                          <span className="font-semibold text-gray-700">
                            {row.type || "Unknown"}
                          </span>
                          <span className="font-mono text-gray-500">
                            {row.count || 0} cases ({pct}%)
                          </span>
                        </div>
                        <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${colors[idx % colors.length]}`}
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* ── Workload Tab ── */}
      {activeTab === "workload" && (
        <div
          key="workload"
          className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden"
        >
          <div className="px-5 py-4 border-b border-gray-100">
            <h2 className="text-sm font-black text-secondary">Team Workload</h2>
            <p className="text-xs text-gray-500 mt-0.5">
              Active cases, overdue cases, and workload metrics
            </p>
          </div>

          {workloadLoading ? (
            <div className="px-5 py-12 text-center">
              <FiLoader
                className="animate-spin inline-block text-secondary mb-2"
                size={28}
              />
              <p className="text-sm text-gray-500">Loading workload data...</p>
            </div>
          ) : workloadError ? (
            <div className="px-5 py-12 text-center">
              <FiAlertCircle
                className="inline-block text-red-500 mb-2"
                size={28}
              />
              <p className="text-sm text-red-500">{workloadError}</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[640px]">
                <thead>
                  <tr className="bg-gray-50 text-left">
                    {[
                      "Caseworker",
                      "Email",
                      "Active",
                      "Overdue",
                      "Pending Tasks",
                      "Workload %",
                      "Health",
                    ].map((h) => (
                      <th
                        key={h}
                        className="px-4 py-3 text-[10px] font-black text-gray-400 uppercase tracking-wider whitespace-nowrap"
                      >
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {filteredWorkload.length === 0 ? (
                    <tr>
                      <td
                        colSpan={7}
                        className="px-4 py-10 text-center text-sm text-gray-400"
                      >
                        No caseworkers match your search.
                      </td>
                    </tr>
                  ) : (
                    filteredWorkload.map((r) => (
                      <tr
                        key={r.caseworker_id}
                        className="hover:bg-gray-50/80 transition-colors"
                      >
                        <td className="px-4 py-3">
                          <span className="text-sm font-bold text-secondary whitespace-nowrap">
                            {r.caseworker_name || "Unknown"}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <span className="text-xs text-gray-500 whitespace-nowrap">
                            {r.email || "N/A"}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-sm font-semibold text-gray-800 tabular-nums">
                          {r.active_cases || 0}
                        </td>
                        <td className="px-4 py-3 text-sm font-semibold text-gray-800 tabular-nums">
                          {r.overdue || 0}
                        </td>
                        <td className="px-4 py-3 text-sm font-semibold text-gray-800 tabular-nums">
                          {r.tasks_pending || 0}
                        </td>
                        <td className="px-4 py-3">
                          <span
                            className={`px-2.5 py-1 rounded-full text-[10px] font-black ${getSlaColor(r.workload_percentage || 0)}`}
                          >
                            {(r.workload_percentage || 0).toFixed(1)}%
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-black ${r.health_color === "green" ? "bg-green-100 text-green-700" : r.health_color === "amber" ? "bg-amber-100 text-amber-800" : "bg-red-100 text-red-700"}`}
                          >
                            {r.health_status || "Unknown"}
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ── Finance Tab ── */}
      {activeTab === "finance" && (
        <div key="finance" className="grid grid-cols-1 xl:grid-cols-2 gap-6">
          {/* Revenue by Visa Type */}
          <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5 sm:p-6">
            <h2 className="text-sm font-black text-secondary pb-3 mb-4 border-b border-gray-100">
              Revenue by Visa Type
            </h2>
            {financeLoading ? (
              <div className="text-center py-8">
                <FiLoader
                  className="animate-spin inline-block text-secondary"
                  size={20}
                />
              </div>
            ) : financeError ? (
              <div className="text-center py-8">
                <FiAlertCircle
                  className="inline-block text-red-500 mb-2"
                  size={20}
                />
                <p className="text-xs text-red-500">Failed to load data</p>
              </div>
            ) : filteredFinanceVisa.length === 0 ? (
              <p className="text-sm text-gray-400 text-center py-8">
                No visa revenue data available.
              </p>
            ) : (
              <div className="flex flex-col gap-2.5">
                {filteredFinanceVisa.map((row) => (
                  <div
                    key={row.visa_type}
                    className="flex justify-between items-center text-sm gap-4"
                  >
                    <span className="text-gray-700 font-medium">
                      {row.visa_type || "Unknown"}
                    </span>
                    <span className="font-mono font-bold text-green-600 tabular-nums shrink-0">
                      £{(row.total_amount || 0).toLocaleString()}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Revenue by Sponsor */}
          <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5 sm:p-6">
            <h2 className="text-sm font-black text-secondary pb-3 mb-4 border-b border-gray-100">
              Revenue by Sponsor
            </h2>
            {financeLoading ? (
              <div className="text-center py-8">
                <FiLoader
                  className="animate-spin inline-block text-secondary"
                  size={20}
                />
              </div>
            ) : financeError ? (
              <div className="text-center py-8">
                <FiAlertCircle
                  className="inline-block text-red-500 mb-2"
                  size={20}
                />
                <p className="text-xs text-red-500">Failed to load data</p>
              </div>
            ) : filteredFinanceSponsor.length === 0 ? (
              <p className="text-sm text-gray-400 text-center py-8">
                No sponsor revenue data available.
              </p>
            ) : (
              <div className="flex flex-col gap-2.5">
                {filteredFinanceSponsor.map((row) => (
                  <div
                    key={row.sponsor_name}
                    className="flex justify-between items-center text-sm gap-4"
                  >
                    <span className="text-gray-700 font-medium">
                      {row.sponsor_name || "Unknown"}
                    </span>
                    <span className="font-mono font-bold text-green-600 tabular-nums shrink-0">
                      £{(row.total_amount || 0).toLocaleString()}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ── Performance Tab ── */}
      {activeTab === "performance" && (
        <PerformanceTab
          dateRange={dateRange}
          performanceData={performanceData || []}
          deptOptions={deptOptions || []}
          showToast={showToast}
          refreshTrigger={refreshTrigger}
        />
      )}
    </div>
  );
}
